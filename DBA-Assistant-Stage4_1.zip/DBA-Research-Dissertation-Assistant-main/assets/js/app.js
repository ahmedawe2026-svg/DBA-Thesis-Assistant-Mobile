
"use strict";
const KEY="thesis-desk-v2",OLD="thesis-desk-v1",TKEY="td-theme";
const CH=[["الجزء التمهيدي",["صفحة العنوان","الإقرار","الشكر والتقدير","الملخص (عربي/إنجليزي)","قوائم المحتويات والجداول والاختصارات"]],
["الفصل الأول: الإطار العام",["المقدمة","خلفية الدراسة","مشكلة الدراسة","أسئلة الدراسة","أهداف الدراسة","أهمية الدراسة","حدود الدراسة","مصطلحات الدراسة","نموذج الدراسة","الفروض المبدئية","المنهج باختصار"]],
["الفصل الثاني: الإطار النظري والدراسات السابقة",["النظرية الحاكمة","المتغير المستقل: مفهوم وأبعاد","المتغير التابع: مفهوم وأبعاد","المتغير الوسيط (إن وجد)","العلاقة النظرية بين المتغيرات","الدراسات العربية","الدراسات الأجنبية","التعليق النقدي والفجوة البحثية","النموذج المفاهيمي واشتقاق الفروض"]],
["الفصل الثالث: المنهجية",["فلسفة ومنهج البحث","تصميم البحث","المجتمع والعينة وحجمها","أداة جمع البيانات والقياس","الدراسة الاستكشافية (المقابلات)","الاختبار التجريبي للأداة","الصدق والثبات","الاعتبارات الأخلاقية","أساليب التحليل وفحص الافتراضات"]],
["الفصل الرابع: النتائج",["وصف العينة","الإحصاء الوصفي","اختبار الفروض","الارتباط والانحدار والتوسط","عرض النتائج في جداول"]],
["الفصل الخامس: المناقشة",["مناقشة ومقارنة النتائج","الاستنتاجات","المساهمة العلمية","المساهمة المهنية","التوصيات وآليات التطبيق","القيود والدراسات المستقبلية"]],
["الجزء الختامي",["المراجع (APA 7)","الملاحق","إفصاح أدوات المساعدة وفحص التشابه"]]];
const ST=["لم يبدأ","جارٍ","مكتمل"];
const AX={iv:"المستقل",dv:"التابع",med:"الوسيط",both:"يجمع المتغيرين"};
const SF=[["author","الباحث"],["year","سنة النشر","n"],["title","عنوان الدراسة"],["goal","الهدف","t"],["hyp","الفرضيات","t"],["vars","المتغيرات","t"],["field","مجال التطبيق"],["pop","المجتمع"],["sample","العينة"],["tools","أدوات جمع البيانات"],["find","أهم النتائج","t"],["agree","أوجه الاتفاق","t"],["differ","أوجه الاختلاف","t"]];
const MF=[["gap","الفجوة البحثية","t"],["q","السؤال"],["obj","الهدف"],["hyp","الفرض"],["inst","الأداة / المحور"],["test","الاختبار الإحصائي"],["res","النتيجة"],["rec","التوصية"]];
const TYPOPT=[["","— غير مصنّف —"],["j","مجلة محكّمة"],["d","رسالة دكتوراة"],["m","رسالة ماجستير"],["c","مؤتمر محكّم"],["r","تقرير / جهة رسمية"],["o","مصدر آخر"]];
const TYPN={j:"مجلة محكّمة",d:"رسالة دكتوراة",m:"رسالة ماجستير",c:"مؤتمر محكّم",r:"تقرير",o:"مصدر آخر","":"—"};
const SRDB=["Scopus","Web of Science","EBSCO","ProQuest","Google Scholar","ScienceDirect","Springer","Wiley","JSTOR","ERIC","PubMed","شمعة SHAMAA","دار المنظومة","أخرى"];
const LBL={ok:"نجاح",wr:"تنبيه",fl:"نقص"};
const uid=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,7);
const esc=s=>String(s==null?"":s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const num=v=>parseInt(v,10)||0;
const cl=o=>JSON.parse(JSON.stringify(o));
const enc=encodeURIComponent;
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const hasAr=s=>/[\u0600-\u06FF]/.test(String(s||""));
const safeUrl=u=>/^https?:\/\//i.test(String(u||""))?String(u):"";
const fmtT=t=>new Date(t).toLocaleString("ar",{year:"numeric",month:"short",day:"numeric",hour:"2-digit",minute:"2-digit"});
const blankP=n=>({id:uid(),name:n||"رسالة جديدة",created:Date.now(),updated:0,lastExp:0,
 p:{title:"",deg:"DBA",sector:"",iv:"",dv:"",med:"",minY:2020,target:10},
 sec:{},studies:[],refs:[],mx:[],sr:[],trash:[],snaps:[]});

/* ===== التخزين والترحيل من النسخة القديمة ===== */
function fixProjs(db){Object.values((db&&db.projects)||{}).forEach(p=>{
 p.sec=p.sec||{};p.studies=p.studies||[];p.refs=p.refs||[];p.mx=p.mx||[];
 p.sr=p.sr||[];p.trash=p.trash||[];p.snaps=p.snaps||[];
 p.p=p.p||{};if(!(num(p.p.minY)>=1))p.p.minY=2020;
 if(!Array.isArray(p.studies))p.studies=[]});
 return db}
let DB=null;
try{DB=JSON.parse(localStorage.getItem(KEY))}catch(e){}
if(!DB||typeof DB!=="object"||!DB.projects){DB={ver:2,cur:null,projects:{}};
 try{const o=JSON.parse(localStorage.getItem(OLD));
  if(o&&o.p){const pr=blankP(o.p.title||"نسخة قديمة مستوردة");
   pr.p=o.p;pr.sec=o.sec||{};pr.studies=o.studies||[];pr.refs=o.refs||[];pr.mx=o.mx||[];pr.updated=Date.now();
   DB.projects[pr.id]=pr;DB.cur=pr.id}}catch(e){}}
fixProjs(DB);
if(!DB.cur||!DB.projects[DB.cur]){const k=Object.keys(DB.projects);DB.cur=k.length?k[0]:null}
if(!DB.cur){const pr=blankP();DB.projects[pr.id]=pr;DB.cur=pr.id}
const P=()=>DB.projects[DB.cur];
const HOME=11,PATH=12;
let S=P(),tab=HOME,uiOpen={},RUN=new Set(),V={busy:0,done:0,total:0};
let F={stQ:"",stAx:"",rfQ:"",rfCat:"",sq:"",stype:"all",slang:"all",sylo:"2020",syhi:"",ag:"",agto:"",agn:"12",elpr:""};

/* ===== الحفظ والمؤشرات ===== */
let svT=null;
function save(){try{S.updated=Date.now()}catch(e){}
 try{localStorage.setItem(KEY,JSON.stringify(DB));
  const el=document.getElementById("saved");el.classList.add("on");
  clearTimeout(svT);svT=setTimeout(()=>el.classList.remove("on"),1200)}
 catch(e){toast("⚠ تعذّر الحفظ: مساحة التخزين ممتلئة. صدّر نسخة فوراً ثم احذف اللقطات القديمة من تبويب النسخ الاحتياطي.",1)}}
let tsT=null;
function toast(m,err){const t=document.getElementById("toast");t.textContent=m;t.className=err?"err":"";
 t.classList.add("show");clearTimeout(tsT);tsT=setTimeout(()=>t.classList.remove("show"),err?8000:2400)}
function copy(txt){try{const ta=document.createElement("textarea");ta.value=txt;ta.style.position="fixed";ta.style.opacity="0";
 document.body.appendChild(ta);ta.select();document.execCommand("copy");ta.remove();return true}catch(e){}
 try{if(navigator.clipboard){navigator.clipboard.writeText(txt);return true}}catch(e){}return false}

/* ===== المظهر ===== */
let thm="";try{thm=localStorage.getItem(TKEY)||""}catch(e){}
function applyTheme(){document.documentElement.dataset.theme=thm;
 const b=document.getElementById("thm");
 b.textContent=thm==="dark"?"🌙":thm==="light"?"☀️":"🖥️";
 b.title="المظهر: "+(thm===""?"تلقائي (حسب النظام)":thm==="light"?"نهاري":"ليلي")+" — انقر للتبديل"}

/* ===== أدوات المرجع / الفحص ===== */
function doiOf(r){const d=String((r&&r.doi)||"").trim().replace(/^https?:\/\/(dx\.)?doi\.org\//i,"");
 return /^10\.\d{4,9}\//.test(d)?d:""}
function normT(s){return String(s==null?"":s).toLowerCase().replace(/[^\p{L}\p{N}]+/gu," ").trim()}
function simT(a,b){const A=new Set(normT(a).split(" ").filter(x=>x.length>2)),B=new Set(normT(b).split(" ").filter(x=>x.length>2));
 if(!A.size||!B.size)return 0;let i=0;A.forEach(x=>{if(B.has(x))i++});return i/Math.max(1,Math.min(A.size,B.size))}
function crYear(m){const o=m.issued||m["published-print"]||m["published-online"]||m.created;return o&&o["date-parts"]?num(o["date-parts"][0][0]):0}
function segEnc(doi){return String(doi).split("/").map(encodeURIComponent).join("/")}
async function jget(u,ms){const c=new AbortController();const t=setTimeout(()=>c.abort(),ms||13000);
 try{const r=await fetch(u,{signal:c.signal,headers:{Accept:"application/json"}});
  if(!r.ok){const e=new Error("HTTP "+r.status);e.http=r.status;throw e}
  return await r.json()}finally{clearTimeout(t)}}

async function coreCheck(o){
 const doi=String(o.doi||"").trim(),title=String(o.title||"").trim(),cite=String(o.cite||"").trim(),y=num(o.year);
 if(!doi&&!title&&!cite)return {t:Date.now(),ok:"fl",msg:"لا يوجد DOI أو عنوان لفحصه"};
 const [a,b]=await Promise.allSettled([
  doi?jget("https://api.crossref.org/works/"+segEnc(doi)):jget("https://api.crossref.org/works?query.bibliographic="+enc(title||cite)+"&rows=5"),
  doi?jget("https://api.openalex.org/works/doi:"+segEnc(doi)+""):jget("https://api.openalex.org/works?search="+enc(title||cite)+"&per-page=5")
 ]);
 let cr=null,oa=null,src=[];
 if(a.status==="fulfilled"){const m=a.value;cr=doi?m:((m.message&&m.message.items&&m.message.items[0])||null);if(cr)src.push("Crossref")}
 if(b.status==="fulfilled"){const m=b.value;oa=doi?m:((m.results&&m.results[0])||null);if(oa)src.push("OpenAlex")}
 if(!cr&&!oa){
  const e1=a.status==="rejected"?a.reason:null;
  if(e1&&e1.http===404)return {t:Date.now(),ok:"fl",msg:"⛔ هذا الـ DOI غير موجود في Crossref — تحقق من صحة الرقم"};
  return {t:Date.now(),ok:"fl",msg:"تعذّر الوصول إلى Crossref/OpenAlex — تأكد من اتصال الإنترنت"}}
 const ct=(cr&&cr.title&&cr.title[0])||(oa&&(oa.title||oa.display_name))||"";
 const refT=title||"";
 const sim=refT&&ct?simT(refT,ct):(cite&&ct?Math.max(.25,Math.min(.95,simT(cite,ct))):null);
 const cY=cr?crYear(cr):0,oY=oa?(oa.publication_year||0):0;
 const py=cY||oY,yOk=!y||!py||Math.abs(py-y)<=1;
 const ret=!!((oa&&oa.is_retracted===true)||(cr&&cr["update-to"]&&cr["update-to"].some(x=>x.type&&/retract/i.test(x.type))));
 const j=(cr&&cr["container-title"]&&cr["container-title"][0])||(oa&&oa.primary_location&&oa.primary_location.source&&oa.primary_location.source.display_name)||"";
 const typ=(cr&&cr.type)||(oa&&oa.type)||"";
 const cited=cr&&cr["is-referenced-by-count"]!=null?cr["is-referenced-by-count"]:(oa&&oa.cited_by_count!=null?oa.cited_by_count:null);
 const oaSt=(oa&&oa.open_access&&oa.open_access.oa_status)||"";
 const aut=cr&&cr.author?cr.author.map(x=>x.family?(x.family+", "+String(x.given||"").split(/\s+/).map(w=>w?w[0]+".":"").join(" ")):(x.name||"")).filter(Boolean).join("; "):"";
 const crDoi=(cr&&cr.DOI)||"";
 const v={t:Date.now(),ok:"ok",msg:"",src:src.join(" + "),ct:ct,cy:py,j:j,typ:typ,cited:cited,oa:oaSt,ret:ret?1:0,sim:sim,
  doi:crDoi||doi,aut:aut,title:ct,sugg:(!doi&&crDoi)?crDoi:""};
 if(ret){v.ok="fl";v.msg="⛔ تنبيه خطير: بيانات النشر تشير إلى أن هذا العمل مسحوب (Retraction) — لا يُستخدم كمرجع"}
 else if(!doi&&crDoi){v.ok=sim!=null&&sim>=.6?"ok":"wr";v.msg="عُثر على سجل مرشّح في "+v.src+" — اعتمد الـ DOI المقترح ثم أعد الفحص لتصديق العنوان"}
 else if(!refT){v.ok="wr";v.msg="السجل موجود في "+v.src+" — لكن أضف «عنوان المرجع» لمقارنته تلقائياً"}
 else if(sim==null){v.ok="wr";v.msg="عُثر على السجل في "+v.src+" دون عنوان للمقارنة"}
 else if(sim>=.6&&yOk){v.ok="ok";v.msg="✓ مطابقة عالية ("+Math.round(sim*100)+"%) مع السجل الرسمي في "+v.src}
 else if(sim>=.35){v.ok="wr";v.msg="مطابقة جزئية ("+Math.round(sim*100)+"%) — راجع العنوان أو السنة"+(yOk?"":" (السنة مختلفة عن السجل)")}
 else {v.ok="fl";v.msg="✗ تعارض: العنوان في "+v.src+" مختلف عن مرجعك ("+Math.round((sim||0)*100)+"%)"+(j?" · المصدر: "+j:"")}
 return v;
}

async function verifyRef(i,quiet){
 const r=S.refs[i];if(!r)return null;
 const doi=doiOf(r),title=String(r.ttl||"").trim();
 if(!doi&&!title&&!String(r.cite||"").trim()){if(!quiet)toast("لا يوجد DOI أو عنوان لفحصه",1);return null}
 if(!quiet){RUN.add(i);render()}
 let v=null;
 try{v=await coreCheck({doi:doi,title:title,cite:r.cite,year:r.year})}
 catch(e){v={t:Date.now(),ok:"fl",msg:"تعذّر الوصول إلى قواعد البيانات — تأكد من اتصال الإنترنت"}}
 if(S.refs[i])S.refs[i].v=v;
 RUN.delete(i);save();
 if(!quiet)render();
 return v;
}
async function verifyAll(){
 if(V.busy){toast("عملية الفحص جارية بالفعل…");return}
 const idx=S.refs.map((r,i)=>i).filter(i=>!S.refs[i].v);
 if(!idx.length){toast("كل المراجع مفحوصة بالفعل");return}
 V={busy:1,done:0,total:idx.length};render();
 for(const i of idx){if(!S.refs[i])continue;await verifyRef(i,true);V.done++;
  const p=document.getElementById("vprog");if(p)p.textContent="اكتمل "+V.done+" من "+V.total;await sleep(280)}
 V.busy=0;save();if(tab===5)render();
 toast("اكتمل فحص "+V.done+" مرجعاً");
}
function parseQ(q){q=String(q||"").trim();const d=q.replace(/^https?:\/\/(dx\.)?doi\.org\//i,"");
 return /^10\.\d{4,9}\//.test(d)?{doi:d,title:""}:{doi:"",title:q}}
function verdictHtml(v,q){
 const bd=v.ok==="ok"?'<span class="badge ok">✓ مطابق</span>':v.ok==="wr"?'<span class="badge wr">⚠ يحتاج مراجعة</span>':'<span class="badge fl">✗ مشكلة</span>';
 return `<div class="rule" style="border-top:0">${bd}<div>${esc(v.msg)}<small>${v.src?("المصدر: "+esc(v.src)+" · "+fmtT(v.t)):"مصدر محلي"}</small></div></div>
 ${(v.ct||v.j)?`<div class="grid">
  <div><label>العنوان في القاعدة</label><div class="mono">${esc(v.ct||"—")}</div></div>
  <div><label>سنة النشر</label><div class="mono">${esc(v.cy||"—")}${v.sim!=null?" · تطابق "+Math.round(v.sim*100)+"%":""}</div></div>
  <div><label>المجلة / الجهة</label><div class="mono">${esc(v.j||"—")}</div></div>
  <div><label>النوع / الاقتباسات${v.oa?" / الوصول":""}</label><div class="mono">${esc(v.typ||"—")} · ${v.cited==null?"—":v.cited}${v.oa?" · "+esc(v.oa):""}</div></div>
 </div>`:""}
 <div class="row">
  ${v.doi?`<a class="mini" target="_blank" rel="noopener" href="https://doi.org/${enc(v.doi)}">فتح DOI</a>`:""}
  ${v.ct?`<a class="mini" target="_blank" rel="noopener" href="https://scholar.google.com/scholar?q=${enc(v.ct)}">Google Scholar</a>
  <a class="mini" target="_blank" rel="noopener" href="https://pubpeer.com/search?q=${enc(v.ct)}">PubPeer</a>`:""}
  ${v.ct?`<a class="mini" target="_blank" rel="noopener" href="https://www.scimagojr.com/journalsearch.php?q=${enc(v.j||v.ct)}">Scimago (تصنيف المجلة)</a>`:""}
 </div>`;
}

/* ===== التحقق ===== */
function validate(){
 const R=[],add=(s,t,d)=>R.push({s:s,t:t,d:d||""}),p=S.p,y=num(p.minY);
 const miss=[["العنوان",p.title],["القطاع",p.sector],["المستقل",p.iv],["التابع",p.dv]].filter(x=>!String(x[1]||"").trim()).map(x=>x[0]);
 add(miss.length?"fl":"ok","اكتمال ملف المشروع",miss.length?"ناقص: "+miss.join("، "):"");
 const axes=["iv","dv"].concat(String(p.med||"").trim()?["med"]:[]).concat(["both"]);
 axes.forEach(a=>{const n=S.studies.filter(x=>x.axis===a).length,t=num(p.target);
  add(n>=t?"ok":(a==="both"&&n===0?"fl":"wr"),"دراسات محور "+AX[a],n+" من "+t+(a==="both"&&n===0?" – هذا المحور أقوى مصدر لتحديد الفجوة":""))});
 const old=S.studies.filter(x=>x.year&&num(x.year)<y);
 add(old.length?"fl":"ok","دراسات أقدم من "+y,old.length?old.map(x=>x.author||"بلا اسم").join("، "):"");
 const inc=S.studies.filter(x=>SF.some(f=>!String(x[f[0]]||"").trim()));
 add(inc.length?"wr":"ok","اكتمال بطاقات الدراسات (13 عنصراً)",inc.length?inc.length+" بطاقة ناقصة":"");
 const ny=S.studies.filter(x=>!num(x.year));
 add(ny.length?"wr":"ok","دراسات بلا سنة نشر",ny.length?ny.length+" بطاقة":"");
 const noTyp=S.studies.filter(x=>!x.typ);
 add(noTyp.length?"wr":"ok","تصنيف مصدر الدراسات",noTyp.length?noTyp.length+" بطاقة بلا نوع مصدر (مجلة محكّمة / رسالة دكتوراة / مؤتمر)":"");
 const dis=S.studies.filter(x=>x.typ==="d").length;
 add(dis?"ok":"wr","الاعتماد على رسائل دكتوراة سابقة",dis?dis+" رسالة دكتوراة ضمن الدراسات السابقة":"لم تُصنّف أي رسالة دكتوراة — أضفها من تبويب الدراسات السابقة");
 const dS=new Set(),dupS=[];
 S.studies.forEach(x=>{const k=((x.author||"")+"|"+(x.year||"")+"|"+String(x.title||"").slice(0,25)).replace(/\s+/g," ").trim().toLowerCase();
  if(!x.author&&!x.title)return;if(dS.has(k))dupS.push(x.author||String(x.title).slice(0,30));else dS.add(k)});
 add(dupS.length?"wr":"ok","دراسات مكررة",dupS.length?dupS.join("، "):"");
 const dR=new Set(),dupR=[];
 S.refs.forEach(r=>{const d=String(r.doi||"").trim().toLowerCase().replace(/^https?:\/\/(dx\.)?doi\.org\//,""),c=String(r.cite||"").trim().replace(/\s+/g," ").toLowerCase();
  if(!d&&!c)return;const k=d?"d:"+d:"c:"+c;
  if(dR.has(k))dupR.push(String(r.cite||"بلا توثيق").slice(0,38));else dR.add(k)});
 add(dupR.length?"fl":"ok","مراجع مكررة",dupR.length?dupR.join("، "):"");
 const badD=S.refs.filter(r=>{const d=String(r.doi||"").trim();return d&&!/^https?:\/\//i.test(d)&&!/^10\.\d{4,9}\//.test(d)});
 add(badD.length?"wr":"ok","صيغة DOI",badD.length?badD.length+" مرجع بنمط غير قياسي (المتوقع 10.xxxx/...)":"");
 const oldA=S.refs.filter(r=>r.year&&num(r.year)<y&&r.cat==="A");
 add(oldA.length?"fl":"ok","مراجع الفئة (أ) الأقدم من "+y,oldA.length?oldA.length+" مرجع – انقلها للفئة (ب) مع تبرير":"");
 const nj=S.refs.filter(r=>r.year&&num(r.year)<y&&r.cat==="B"&&!String(r.just||"").trim());
 add(nj.length?"fl":"ok","تبرير المراجع التأسيسية الأقدم",nj.length?nj.length+" مرجع بلا تبرير":"");
 const nd=S.refs.filter(r=>!String(r.doi||"").trim()),np=S.refs.filter(r=>r.cat==="A"&&!r.peer);
 add(nd.length?"wr":"ok","مراجع بلا DOI",nd.length?nd.length+" مرجع":"");
 add(np.length?"wr":"ok","دراسات (أ) غير محكّمة",np.length?np.length+" مرجع":"");
 const noTtl=S.refs.filter(r=>r.cat==="A"&&!String(r.ttl||"").trim());
 add(noTtl.length?"wr":"ok","عنوان مستقل لمراجع الفئة (أ)",noTtl.length?noTtl.length+" مرجع بلا عنوان مستقل (يُصعّب فحصه آلياً)":"");
 const unv=S.refs.filter(r=>!r.v&&(doiOf(r)||String(r.ttl||"").trim()||String(r.cite||"").trim()));
 add(unv.length?"wr":"ok","الفحص المباشر للمراجع",unv.length?unv.length+" مرجع لم يُفحص عبر Crossref/OpenAlex — تبويب: فحص المراجع":"");
 const badv=S.refs.filter(r=>r.v&&(r.v.ok==="fl"||r.v.ret));
 add(badv.length?"fl":"ok","نتائج فحص المراجع",badv.length?badv.map(r=>(r.v.ret?"مسحوب: ":"تعارض: ")+String(r.cite||r.ttl||"").slice(0,32)).join("، "):"");
 add(S.sr.length?"ok":"wr","توثيق استراتيجية البحث",S.sr.length?S.sr.length+" عملية بحث موثّقة — جاهزة للتصدير في فصل المنهجية":"لم تُوثّق القواعد والاستعلامات والتواريخ (تبويب: البحث الأكاديمي)");
 add(S.mx.length?"ok":"wr","مصفوفة الاتساق",S.mx.length?S.mx.length+" صف":"لم تُدخل أي صف");
 const q=S.mx.filter(m=>String(m.q||"").trim());
 const a1=q.filter(m=>!String(m.obj||"").trim()),b1=q.filter(m=>m.qt!=="d"&&!String(m.hyp||"").trim()),
 c1=q.filter(m=>m.qt!=="d"&&!(String(m.inst||"").trim()&&String(m.test||"").trim())),
 gp=S.mx.filter(m=>!String(m.gap||"").trim()),
 nr=q.filter(m=>!String(m.res||"").trim()||!String(m.rec||"").trim());
 add(a1.length?"fl":"ok","كل سؤال له هدف",a1.length?a1.length+" سؤال بلا هدف":"");
 add(b1.length?"fl":"ok","كل سؤال اختباري له فرض",b1.length?b1.length+" سؤال بلا فرض":"");
 add(c1.length?"wr":"ok","الفرض مرتبط بأداة واختبار",c1.length?c1.length+" صف ناقص":"");
 add(gp.length?"wr":"ok","ربط الصفوف بالفجوة",gp.length?gp.length+" صف بلا فجوة":"");
 add(nr.length?"wr":"ok","اكتمال النتيجة والتوصية",nr.length?nr.length+" صف ناقص":"");
 return R;
}
function progress(){let d=0,t=0;CH.forEach((c,i)=>c[1].forEach((s,j)=>{t++;d+=(S.sec[i+"-"+j]||{}).st===2?1:0}));return[d,t]}

/* ===== التصدير ===== */
function dl(name,content,type){const a=document.createElement("a");
 a.href=URL.createObjectURL(new Blob([content],{type:type}));a.download=name;
 document.body.appendChild(a);a.click();a.remove();P().lastExp=Date.now();save()}
function wordDoc(title,body){return '\ufeff<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40"><head><meta charset="utf-8"><title>'+esc(title)+'</title><style>body{font-family:Arial,sans-serif;direction:rtl;text-align:right}h2{color:#2f5fe0}h3{color:#16307f}table{border-collapse:collapse;width:100%;margin-bottom:14px}th,td{border:1px solid #8a94a6;padding:5px 7px;font-size:10.5pt;text-align:right;vertical-align:top}th{background:#e9eeff}</style></head><body dir="rtl"><h2>'+esc(title)+'</h2><p>أُنشئ بواسطة «مكتب الرسالة v3» – '+fmtT(Date.now())+'</p>'+body+'</body></html>'}
function exportWord(name,title,body){dl(name,wordDoc(title,body),"application/msword;charset=utf-8");toast("تم تصدير "+name)}
function exportCsv(name,rows){dl(name,"\ufeff"+rows.map(r=>r.map(c=>'"'+String(c==null?"":c).replace(/"/g,'""').replace(/\r?\n/g," ")+'"').join(",")).join("\r\n"),"text/csv;charset=utf-8");toast("تم تصدير "+name)}
function exportRows(name,header,rows){exportCsv(name,[header].concat(rows))}
function studiesTable(l){return "<table><tr><th>#</th><th>المحور</th><th>نوع المصدر</th>"+SF.map(f=>"<th>"+f[1]+"</th>").join("")+"<th>المجلة/الجهة</th><th>DOI</th><th>التصنيف</th><th>قاعدة البيانات</th><th>المنهج</th></tr>"+l.map((x,i)=>"<tr><td>"+(i+1)+"</td><td>"+(AX[x.axis]||"")+"</td><td>"+(TYPN[x.typ]||"")+"</td>"+SF.map(f=>"<td>"+esc(x[f[0]])+"</td>").join("")+"<td>"+esc(x.jr)+"</td><td>"+esc(x.doi)+"</td><td>"+esc(x.qu)+"</td><td>"+esc(x.db)+"</td><td>"+esc(x.meth)+"</td></tr>").join("")+"</table>"}
const VERST=r=>{const v=r.v;return !v?"لم يُفحص":v.ret?"مسحوب":v.ok==="ok"?"مطابق":v.ok==="wr"?"مراجعة":"تعارض"};
function refsBody(l){return "<table><tr><th>#</th><th>الفئة</th><th>التوثيق (APA 7)</th><th>العنوان</th><th>المؤلفون</th><th>المجلة/الجهة</th><th>السنة</th><th>اللغة</th><th>DOI/رابط</th><th>محكّم</th><th>حالة الفحص</th><th>تبرير</th></tr>"+l.map((x,i)=>"<tr><td>"+(i+1)+"</td><td>"+({A:"أ",B:"ب",C:"ج"}[x.cat]||"")+"</td><td>"+esc(x.cite)+"</td><td>"+esc(x.ttl)+"</td><td>"+esc(x.aut)+"</td><td>"+esc(x.jr)+"</td><td>"+esc(x.year)+"</td><td>"+(x.lang==="ar"?"عربي":"إنجليزي")+"</td><td>"+esc(x.doi)+"</td><td>"+(x.peer?"نعم":"-")+"</td><td>"+VERST(x)+"</td><td>"+esc(x.just)+"</td></tr>").join("")+"</table>"}
function mxBody(l){return "<table><tr><th>#</th><th>النوع</th>"+MF.map(f=>"<th>"+f[1]+"</th>").join("")+"</tr>"+l.map((x,i)=>"<tr><td>"+(i+1)+"</td><td>"+(x.qt==="d"?"وصفي":"اختباري")+"</td>"+MF.map(f=>"<td>"+esc(x[f[0]])+"</td>").join("")+"</tr>").join("")+"</table>"}
function structBody(){return CH.map((c,i)=>"<h3>"+esc(c[0])+"</h3><table><tr><th>القسم</th><th>الحالة</th><th>ملاحظات</th></tr>"+c[1].map((s,j)=>{const o=S.sec[i+"-"+j]||{};return "<tr><td>"+esc(s)+"</td><td>"+(ST[num(o.st)]||ST[0])+"</td><td>"+esc(o.note)+"</td></tr>"}).join("")+"</table>").join("")}
function srBody(){return "<table><tr><th>#</th><th>قاعدة البيانات</th><th>التاريخ</th><th>نص الاستعلام</th><th>السنوات</th><th>عدد النتائج</th><th>ملاحظات</th></tr>"+S.sr.map((x,i)=>"<tr><td>"+(i+1)+"</td><td>"+esc(x.db)+"</td><td>"+esc(x.date)+"</td><td>"+esc(x.q)+"</td><td>"+esc((x.ylo||"")+(x.ylo||x.yhi?"–":"")+(x.yhi||""))+"</td><td>"+esc(x.n)+"</td><td>"+esc(x.note)+"</td></tr>").join("")+"</table>"}
function verBody(){return "<table><tr><th>#</th><th>المرجع (APA)</th><th>الحالة</th><th>النتيجة</th><th>DOI</th><th>المجلة/الجهة</th><th>آخر فحص</th></tr>"+S.refs.map((r,i)=>"<tr><td>"+(i+1)+"</td><td>"+esc(r.cite||r.ttl||"")+"</td><td>"+VERST(r)+"</td><td>"+esc(r.v?r.v.msg:"—")+"</td><td>"+esc(doiOf(r)||r.doi||"")+"</td><td>"+esc(r.v?r.v.j:"")+"</td><td>"+(r.v?fmtT(r.v.t):"")+"</td></tr>").join("")+"</table>"}

/* ===== اللقطات ===== */
function snapshot(label){const pr=P();
 pr.snaps.unshift({t:Date.now(),label:label||"لقطة يدوية",d:cl({p:pr.p,sec:pr.sec,studies:pr.studies,refs:pr.refs,mx:pr.mx,sr:pr.sr})});
 if(pr.snaps.length>5)pr.snaps.length=5;save();render();toast("حُفظت لقطة كاملة للمشروع")}

/* ===== العروض ===== */
function vSummary(){
 const R=validate(),n=k=>R.filter(r=>r.s===k).length,pr=progress(),d=pr[0],t=pr[1];
 const refs=S.refs,st=S.studies,a=refs.filter(r=>r.cat==="A"),peer=a.filter(r=>r.peer).length,ar=refs.filter(r=>r.lang==="ar").length;
 const doneCards=st.filter(x=>SF.every(f=>String(x[f[0]]||"").trim())).length;
 const dis=st.filter(x=>x.typ==="d").length;
 const verDone=refs.filter(r=>r.v&&r.v.ok==="ok").length,ret=refs.filter(r=>r.v&&r.v.ret).length;
 const yrs={};st.forEach(x=>{const yy=num(x.year);if(yy)yrs[yy]=(yrs[yy]||0)+1});
 const yk=Object.keys(yrs).sort();
 return `<div class="ledger"><div class="ok"><b>${n("ok")}</b>نجاح</div><div class="wr"><b>${n("wr")}</b>تنبيه</div><div class="fl"><b>${n("fl")}</b>نقص</div></div>
 <div class="card"><h3>تقدم الأقسام: ${d} من ${t}</h3><div class="bar"><i style="width:${t?Math.round(d/t*100):0}%"></i></div></div>
 <div class="card"><h2>مدخل سريع</h2><p class="hint">انتقل مباشرة إلى أدوات البحث والتحقق الأكاديمي.</p>
 <div class="row"><button class="btn" data-tab="10">🤖 المولّد الآلي</button>
 <button class="btn" data-tab="5">🔎 فحص المراجع</button>
 <button class="btn" data-tab="6">🔍 البحث الأكاديمي</button>
 <button class="btn sec" data-tab="3">📚 الدراسات السابقة</button>
 <button class="btn sec" data-tab="4">🔗 سجل المراجع</button></div></div>
 <div class="card"><h3>إحصاءات سريعة</h3><div class="count">
 <span>دراسات: ${st.length}</span><span>بطاقات مكتملة: ${doneCards}/${st.length}</span><span>رسائل دكتوراة: ${dis}</span>
 <span>مراجع: ${refs.length}</span><span>فئة (أ): ${a.length}</span>
 <span>محكّم: ${peer}${a.length?" ("+Math.round(peer/a.length*100)+"%)":""}</span>
 <span>عربي: ${ar} / إنجليزي: ${refs.length-ar}</span>
 <span>مراجع مفحوصة: ${verDone}</span><span>مسحوبة: ${ret}</span>
 <span>صفوف المصفوفة: ${S.mx.length}</span><span>سجلات البحث: ${S.sr.length}</span></div>
 ${yk.length?`<p class="hint" style="margin:0">سنوات الدراسات: ${yk.map(k=>k+" ×"+yrs[k]).join("، ")}</p>`:""}</div>
 <div class="card"><h2>لوحة التحقق</h2><p class="hint">تُحدَّث تلقائياً مع كل تعديل. ابدأ بحالات «نقص» ثم «تنبيه».</p>
 ${R.slice().sort((x,z)=>"fl wr ok".indexOf(x.s)-"fl wr ok".indexOf(z.s)).map(r=>`<div class="rule"><span class="badge ${r.s}">${LBL[r.s]}</span><div>${esc(r.t)}${r.d?`<small>${esc(r.d)}</small>`:""}</div></div>`).join("")}</div>`;
}

function fld(l,i,k,lab,type,v){
 const a=`data-l="${l}" data-i="${i}" data-k="${k}"`;
 const it=type==="t"?`<textarea ${a}>${esc(v)}</textarea>`:`<input ${a}${type==="n"?' type="number" inputmode="numeric"':type==="d"?' type="date"':""} value="${esc(v)}">`;
 return `<label>${lab}</label>${it}`}
function selF(l,i,k,lab,opts,v){return `<label>${lab}</label><select data-l="${l}" data-i="${i}" data-k="${k}">${opts.map(o=>`<option value="${o[0]}" ${v===o[0]?"selected":""}>${o[1]}</option>`).join("")}</select>`}

function vProfile(){const p=S.p,f=(k,l,t)=>fld("p","",k,l,t,p[k]);
 return `<div class="card"><h2>ملف المشروع</h2>
 <p class="hint">كل قواعد التحقق تعتمد على هذه البيانات. اسم المشروع يميّزه في قائمة المشاريع أعلى الصفحة.<br>أُنشئ: ${fmtT(P().created)} · آخر تعديل: ${P().updated?fmtT(P().updated):"—"}</p>
 <label>اسم المشروع (للتمييز في القائمة)</label><input data-l="meta" data-k="name" value="${esc(P().name)}">
 <div class="grid">
 ${f("title","عنوان الرسالة")}${f("sector","القطاع / مجال التطبيق")}${f("iv","المتغير المستقل")}${f("dv","المتغير التابع")}${f("med","المتغير الوسيط (اختياري)")}
 <div><label>نوع الدرجة</label><select data-l="p" data-i="" data-k="deg">${["DBA","PhD"].map(x=>`<option ${p.deg===x?"selected":""}>${x}</option>`).join("")}</select></div>
 ${f("minY","أقدم سنة نشر مسموحة","n")}${f("target","الحد الأدنى المستهدف لكل محور","n")}</div></div>`}

function vStruct(){
 return `<div class="card"><h2>متتبع الهيكل</h2><p class="hint">حدّث حالة كل قسم وأضف ملاحظات المشرف أو اللجنة، وصدّر الهيكل لإرفاقه بتقارير التقدم.</p>
 <div class="row"><button class="btn sec" id="expStruct">تصدير الهيكل (Word)</button></div></div>`+
 CH.map((c,i)=>{const dn=c[1].filter((s,j)=>num((S.sec[i+"-"+j]||{}).st)===2).length,tot=c[1].length;
  return `<div class="card"><h3>${esc(c[0])} <span class="badge ${dn===tot?"ok":dn?"wr":"fl"}">${dn}/${tot}</span></h3>`+
  c[1].map((s,j)=>{const k=i+"-"+j,o=S.sec[k]||{};
   return `<div class="sec-row"><div>${esc(s)}</div><select data-l="sec" data-i="${k}" data-k="st" aria-label="حالة ${esc(s)}">${ST.map((x,n2)=>`<option value="${n2}" ${num(o.st)===n2?"selected":""}>${x}</option>`).join("")}</select>
   <textarea data-l="sec" data-i="${k}" data-k="note" placeholder="ملاحظات المشرف" aria-label="ملاحظات ${esc(s)}">${esc(o.note)}</textarea></div>`}).join("")+"</div>"}).join("")}

function counts(){const a=["iv","dv"].concat(String(S.p.med||"").trim()?["med"]:[]).concat(["both"]);
 return `<div class="count">${a.map(k=>`<span>${AX[k]}: ${S.studies.filter(x=>x.axis===k).length}/${num(S.p.target)}</span>`).join("")}</div>`}

function stFiltered(){return S.studies.map((x,i)=>[x,i]).filter(([x])=>{
 if(F.stAx&&x.axis!==F.stAx)return false;
 if(F.stQ){const hay=Object.keys(x).map(k=>x[k]).join(" ").toLowerCase();if(!hay.includes(F.stQ.toLowerCase()))return false}
 return true})}
function studyLinks(x){const ti=String(x.title||"").trim(),raw=String(x.doi||"").trim();
 const d=raw.replace(/^https?:\/\/(dx\.)?doi\.org\//i,""),isDoi=/^10\.\d{4,9}\//.test(d);
 if(!ti&&!raw)return "";
 return `<div class="row">${ti?`<a class="mini" target="_blank" rel="noopener" href="https://scholar.google.com/scholar?q=${enc(ti)}">🔎 بحث في Scholar</a>
 <a class="mini" target="_blank" rel="noopener" href="https://search.crossref.org/?q=${enc(ti)}">Crossref</a>
 <a class="mini" target="_blank" rel="noopener" href="https://www.google.com/search?q=${enc('"'+ti+'"')}">Google</a>`:""}
 ${isDoi?`<a class="mini" target="_blank" rel="noopener" href="https://doi.org/${enc(d)}">DOI</a>`:(safeUrl(raw)?`<a class="mini" target="_blank" rel="noopener" href="${esc(safeUrl(raw))}">رابط الدراسة</a>`:"")}</div>`}
function studiesHtml(){const l=stFiltered();
 if(!S.studies.length)return `<div class="empty">لا توجد دراسات بعد. أضف أول بطاقة من الأعلى.</div>`;
 if(!l.length)return `<div class="empty">لا نتائج مطابقة للبحث.</div>`;
 return l.map(([x,i])=>{const open=!!uiOpen["studies"+i];
  const warn=x.year&&num(x.year)<num(S.p.minY)?`<p><span class="badge fl">سنة النشر أقدم من ${esc(S.p.minY)}</span></p>`:"";
  const miss=SF.filter(f=>!String(x[f[0]]||"").trim()).length;
  return `<div class="card"><div class="row"><h3 style="margin:0;flex:1">${esc(x.author||x.title||"بلا اسم")} ${x.typ?`<span class="badge ok">${TYPN[x.typ]||"مصدر"}</span>`:""} ${miss?`<span class="badge wr">ناقص ${miss}</span>`:`<span class="badge ok">مكتملة</span>`}</h3>
  <button class="btn sec" data-tog="studies${i}">${open?"إغلاق":"فتح"}</button>
  <button class="btn sec" data-dup="studies" data-i="${i}">تكرار</button>
  <button class="btn del" data-del="studies" data-i="${i}">حذف</button></div>
  ${studyLinks(x)}
  ${open?warn+`<div class="grid">${selF("studies",i,"axis","المحور",Object.keys(AX).map(k=>[k,AX[k]]),x.axis)}${selF("studies",i,"typ","نوع المصدر",TYPOPT,x.typ||"")}
  ${SF.map(f=>fld("studies",i,f[0],f[1],f[2],x[f[0]])).join("")}
  ${fld("studies",i,"jr","اسم المجلة / الجهة الناشرة","",x.jr)}${fld("studies",i,"doi","DOI أو الرابط","",x.doi)}
  ${fld("studies",i,"qu","التصنيف (Q1–Q4 / JCR / Scopus)","",x.qu)}${fld("studies",i,"db","قاعدة البيانات التي وُجدت فيها","",x.db)}
  ${fld("studies",i,"meth","المنهج / التصميم","",x.meth)}</div>`:""}</div>`}).join("")}
function vStudies(){
 return `<div class="card"><h2>قاعدة الدراسات السابقة</h2><p class="hint">بطاقة لكل دراسة بالعناصر الثلاثة عشر، من مصدرك الأصلي. صنّف «نوع المصدر» (مجلة محكّمة / رسالة دكتوراة / مؤتمر) واستخدم أزرار البحث للوصول إلى المصدر وتوثيقه. التصدير يشمل نتائج البحث والتصفية الحالية.</p>
 ${counts()}
 <div class="row">
  <input id="stQ" placeholder="بحث في كل حقول البطاقات…" value="${esc(F.stQ)}" style="flex:1;min-width:180px">
  <select id="stAx" style="width:auto"><option value="">كل المحاور</option>${Object.keys(AX).map(k=>`<option value="${k}" ${F.stAx===k?"selected":""}>${AX[k]}</option>`).join("")}</select>
  <button class="btn" data-add="studies">إضافة دراسة</button>
  <button class="btn sec" id="expStW">Word</button><button class="btn sec" id="expStC">Excel/CSV</button>
 </div></div><div id="list-studies">${studiesHtml()}</div>`}

function dupRefIdx(){const seen=new Map(),dups=new Set();
 S.refs.forEach((r,i)=>{const d=String(r.doi||"").trim().toLowerCase().replace(/^https?:\/\/(dx\.)?doi\.org\//,""),c=String(r.cite||"").trim().replace(/\s+/g," ").toLowerCase();
  if(!d&&!c)return;const k=d?"d:"+d:"c:"+c;
  if(seen.has(k)){dups.add(i);dups.add(seen.get(k))}else seen.set(k,i)});return dups}
function rfFiltered(){return S.refs.map((x,i)=>[x,i]).filter(([x])=>{
 if(F.rfCat&&x.cat!==F.rfCat)return false;
 if(F.rfQ){const hay=[x.cite,x.doi,x.just,x.ttl,x.aut,x.jr].join(" ").toLowerCase();if(!hay.includes(F.rfQ.toLowerCase()))return false}
 return true})}
function refLinks(x,i){const doi=doiOf(x),raw=String(x.doi||"").trim(),ti=String(x.ttl||x.cite||"").trim();
 return `<div class="row">
 ${doi?`<a class="mini" target="_blank" rel="noopener" href="https://doi.org/${enc(doi)}">DOI</a>`:(safeUrl(raw)?`<a class="mini" target="_blank" rel="noopener" href="${esc(safeUrl(raw))}">الرابط</a>`:"")}
 ${ti?`<a class="mini" target="_blank" rel="noopener" href="https://scholar.google.com/scholar?q=${enc(ti)}">Scholar</a>
 <a class="mini" target="_blank" rel="noopener" href="https://search.crossref.org/?q=${enc(ti)}">Crossref</a>`:""}
 ${x.jr?`<a class="mini" target="_blank" rel="noopener" href="https://www.scimagojr.com/journalsearch.php?q=${enc(x.jr)}">تصنيف المجلة (Scimago)</a>`:""}
 <button class="mini" data-ver="${i}">🔎 تحقق</button></div>`}
function refsHtml(){const dups=dupRefIdx(),l=rfFiltered();
 if(!S.refs.length)return `<div class="empty">لا مراجع بعد. أضف أول مرجع من الأعلى.</div>`;
 if(!l.length)return `<div class="empty">لا نتائج مطابقة للبحث.</div>`;
 return l.map(([x,i])=>{const open=!!uiOpen["refs"+i],y=num(x.year),b=[];
  const v=x.v;if(v)b.push(v.ret?'<span class="badge fl">⛔ مسحوب</span>':v.ok==="ok"?'<span class="badge ok">✓ متحقق</span>':v.ok==="wr"?'<span class="badge wr">⚠ مراجعة</span>':'<span class="badge fl">✗ تعارض</span>');else if(RUN.has(i))b.push('<span class="badge wr">⟳ جارٍ</span>');
  if(dups.has(i))b.push('<span class="badge fl">مكرر</span>');
  if(y&&y<num(S.p.minY)&&x.cat!=="C")b.push(`<span class="badge wr">أقدم من ${esc(S.p.minY)}</span>`);
  if(x.cat==="A"&&!x.peer)b.push('<span class="badge wr">غير محكّم</span>');
  const dd=String(x.doi||"").trim()&&!/^https?:\/\//i.test(x.doi)&&!/^10\.\d{4,9}\//.test(x.doi);
  if(dd)b.push('<span class="badge wr">DOI غير قياسي</span>');
  return `<div class="card"><div class="row"><h3 style="margin:0;flex:1">${esc(x.cite||"بلا توثيق")} ${b.join(" ")}</h3>
  <button class="btn sec" data-tog="refs${i}">${open?"إغلاق":"فتح"}</button>
  <button class="btn sec" data-dup="refs" data-i="${i}">تكرار</button>
  <button class="btn del" data-del="refs" data-i="${i}">حذف</button></div>
  ${refLinks(x,i)}
  ${open?`<div class="grid">${fld("refs",i,"cite","التوثيق (APA 7)","t",x.cite)}
  ${fld("refs",i,"ttl","عنوان المرجع (للفحص التلقائي)","",x.ttl)}${fld("refs",i,"aut","المؤلفون","",x.aut)}
  ${fld("refs",i,"year","سنة النشر","n",x.year)}${fld("refs",i,"jr","المجلة / الجهة الناشرة","",x.jr)}
  ${selF("refs",i,"cat","الفئة",[["A","أ: دراسة حديثة"],["B","ب: تأسيسي"],["C","ج: سياقي"]],x.cat)}${selF("refs",i,"lang","اللغة",[["ar","عربي"],["en","إنجليزي"]],x.lang)}
  ${fld("refs",i,"doi","DOI أو الرابط","",x.doi)}
  <div><label>محكّم</label><label style="display:flex;gap:8px;align-items:center;color:var(--ink);margin:0"><input type="checkbox" data-l="refs" data-i="${i}" data-k="peer" ${x.peer?"checked":""} style="width:auto"> مُحكَّم (Peer-reviewed)</label></div></div>
  ${fld("refs",i,"just","تبرير استخدام مرجع أقدم (إن لزم)","t",x.just)}
  ${v?`<div class="rule"><span class="badge ${v.ret||v.ok==="fl"?"fl":v.ok}">${VERST(x)}</span><div>${esc(v.msg)}<small>${v.j?"المجلة/الجهة: "+esc(v.j)+" · ":""}آخر فحص: ${fmtT(v.t)}</small></div></div>`:""}`:""}</div>`}).join("")}
function vRefs(){
 return `<div class="card"><h2>سجل المراجع</h2><p class="hint">صنّف كل مرجع: (أ) دراسة حديثة محكّمة، (ب) تأسيسي بتبرير، (ج) سياقي. تظهر شارات التحقق والتحذير مباشرة على كل بطاقة. استخدم زر «تحقق» لفحص المرجع عبر الإنترنت.</p>
 <div class="row">
  <input id="rfQ" placeholder="بحث في التوثيق/العنوان/المؤلفين/DOI/المجلة…" value="${esc(F.rfQ)}" style="flex:1;min-width:180px">
  <select id="rfCat" style="width:auto"><option value="">كل الفئات</option>
  <option value="A" ${F.rfCat==="A"?"selected":""}>أ: حديثة</option>
  <option value="B" ${F.rfCat==="B"?"selected":""}>ب: تأسيسي</option>
  <option value="C" ${F.rfCat==="C"?"selected":""}>ج: سياقي</option></select>
  <button class="btn" data-add="refs">إضافة مرجع</button>
  <button class="btn sec" id="expRfW">Word</button><button class="btn sec" id="expRfC">Excel/CSV</button>
 </div>
 <div class="row"><button class="btn" id="adddoi">＋ إضافة مرجع تلقائياً عبر DOI (Crossref)</button>
 <span class="hint" style="margin:0">جلب بيانات السجل الرسمي وتوليد التوثيق تلقائياً.</span></div></div><div id="list-refs">${refsHtml()}</div>`}

const MANUAL=`<a class="mini" target="_blank" rel="noopener" href="https://doi.org/">🔗 doi.org</a>
<a class="mini" target="_blank" rel="noopener" href="https://search.crossref.org/">Crossref</a>
<a class="mini" target="_blank" rel="noopener" href="https://openalex.org/">OpenAlex</a>
<a class="mini" target="_blank" rel="noopener" href="https://scholar.google.com/">Google Scholar</a>
<a class="mini" target="_blank" rel="noopener" href="https://www.scopus.com/">Scopus</a>
<a class="mini" target="_blank" rel="noopener" href="https://www.webofscience.com/wos/woscc/basic-search">Web of Science</a>
<a class="mini" target="_blank" rel="noopener" href="https://orcid.org/orcid-search/search">ORCID (الباحثون)</a>
<a class="mini" target="_blank" rel="noopener" href="https://www.scimagojr.com/">Scimago (تصنيف المجلات)</a>
<a class="mini" target="_blank" rel="noopener" href="https://beallslist.net/">Beall's (المجلات المُنصّبة)</a>
<a class="mini" target="_blank" rel="noopener" href="https://doaj.org/">DOAJ</a>
<a class="mini" target="_blank" rel="noopener" href="https://pubpeer.com/">PubPeer</a>
<a class="mini" target="_blank" rel="noopener" href="https://retractionwatch.com/">Retraction Watch</a>`;
function vVerify(){
 const refs=S.refs,wd=refs.filter(r=>doiOf(r)).length,ok=refs.filter(r=>r.v&&r.v.ok==="ok").length,
 ret=refs.filter(r=>r.v&&r.v.ret).length,bad=refs.filter(r=>r.v&&r.v.ok==="fl"&&!r.v.ret).length,
 un=refs.filter(r=>!r.v).length;
 const rows=refs.length?refs.map((r,i)=>{const v=r.v,run=RUN.has(i)&&!v;
  let bd=v?(v.ret?'<span class="badge fl">⛔ مسحوب</span>':v.ok==="ok"?'<span class="badge ok">✓ متحقق</span>':v.ok==="wr"?'<span class="badge wr">⚠ مراجعة</span>':'<span class="badge fl">✗ تعارض</span>'):(run?'<span class="badge wr">⟳ جارٍ</span>':'<span class="badge wr">لم يُفحص</span>');
  const doi=doiOf(r),raw=String(r.doi||"").trim();
  return `<div class="rule">${bd}<div>${esc(r.cite||r.ttl||"بلا توثيق")}<small>${v?esc(v.msg)+(v.j?" · "+esc(v.j):"")+(v.cited!=null?" · اقتباسات: "+v.cited:""):"اضغط «فحص» لجلب بيانات Crossref/OpenAlex"}</small></div>
  <div class="row">${run?`<button class="mini" disabled>…</button>`:`<button class="mini" data-ver="${i}">🔎 فحص</button>`}
  ${doi?`<a class="mini" target="_blank" rel="noopener" href="https://doi.org/${enc(doi)}">DOI</a>`:(safeUrl(raw)?`<a class="mini" target="_blank" rel="noopener" href="${esc(safeUrl(raw))}">الرابط</a>`:"")}
  ${v&&v.sugg?`<button class="mini" data-adddoi="${i}">اعتماد DOI المقترح</button>`:""}
  ${v&&v.ct?`<button class="mini" data-applyv="${i}">اعتماد بيانات السجل</button>`:""}</div></div>`}).join(""):`<div class="empty">لا مراجع بعد. أضفها من تبويب «سجل المراجع».</div>`;
 return `<div class="ledger">
  <div class="wr"><b>${refs.length}</b>إجمالي المراجع</div>
  <div class="wr"><b>${wd}</b>لديها DOI</div>
  <div class="ok"><b>${ok}</b>تم التحقق</div>
  <div class="fl"><b>${bad+ret}</b>مشكلات (منها ${ret} مسحوب)</div></div>
 <div class="card"><h2>فاحص سريع (DOI أو عنوان)</h2>
 <p class="hint">الصق <b>DOI</b> (مثال: 10.1016/j.chb.2023.109412) أو <b>عنوان أي بحث</b>. يجلب النظام بيانات <b>Crossref</b> و<b>OpenAlex</b> ويقارن العنوان والسنة، ويتحقق من <b>سحب النشر</b>، ويقترح الـ DOI الصحيح.</p>
 <div class="row"><input id="vq" placeholder="DOI أو عنوان المرجع…" style="flex:1;min-width:220px"><button class="btn" id="vgo">🔎 تحقّق الآن</button></div>
 <div id="vout"></div>
 <div class="gh">أدوات تحقق يدوية</div><div class="row">${MANUAL}</div></div>
 <div class="card"><h2>حالة التحقق لكل مرجع</h2>
 <p class="hint">الفحص آلي بالكامل عبر واجهات Crossref وOpenAlex الرسمية.${un?` <b>${un}</b> مرجع بانتظار الفحص.`:""}</p>
 <div class="row"><button class="btn" id="vall">⚡ فحص كل المراجع غير المفحوصة</button><span class="hint" style="margin:0" id="vprog">${V.busy?"اكتمل "+V.done+" من "+V.total:""}</span><button class="btn sec" id="expVW">تصدير تقرير الفحص (Word)</button></div>
 ${rows}</div>`;
}

/* ===== البحث الأكاديمي ===== */
function Q(){let q=String(F.sq||"").trim().replace(/\s+/g," ");if(!q)return"";
 if(F.stype==="thesis")q+=hasAr(q)?" رسالة دكتوراه":" dissertation OR \"phd thesis\"";
 if(F.stype==="article")q+=hasAr(q)?" مقالة محكّمة":" \"peer-reviewed\" article";
 return q}
function yrP(){return (F.sylo?"&as_ylo="+enc(F.sylo):"")+(F.syhi?"&as_yhi="+enc(F.syhi):"")}
function lrP(){return F.slang==="ar"?"&lr=lang_ar":F.slang==="en"?"&lr=lang_en":""}
function cdrP(){const a=/^\d{4}$/.test(F.sylo)?F.sylo:"",b=/^\d{4}$/.test(F.syhi)?F.syhi:"";
 if(!a&&!b)return"";return "&tbs=cdr:1"+(a?",cd_min:1/1/"+a:"")+(b?",cd_max:12/31/"+b:"")}
function siteQ(dom){return "https://www.google.com/search?q="+enc("site:"+dom+" "+Q())+cdrP()}
const GROUPS=[
{n:"📘 رسائل الدكتوراه والدراسات العليا",items:[
 {n:"Google Scholar",s:"أوسع فهرس أكاديمي، ويتضمن الرسائل والفضاءات الجامعية",u:()=>"https://scholar.google.com/scholar?hl="+(F.slang==="ar"?"ar":"en")+"&q="+enc(Q())+yrP()},
 {n:"Google — ملفات PDF",s:"نتائج جوجل المقيّدة بملفات PDF (الرسائل غالباً PDF)",u:()=>"https://www.google.com/search?q="+enc(Q()+" filetype:pdf")+lrP()+cdrP()},
 {n:"Google — site:proquest.com",s:"صفحات الرسائل داخل قاعدة ProQuest العالمية",u:()=>siteQ("proquest.com")},
 {n:"Google — site:ethos.bl.uk",s:"صفحات رسائل EThOS البريطانية",u:()=>siteQ("ethos.bl.uk")},
 {n:"ProQuest Dissertations",s:"أكبر قاعدة رسائل دكتوراة عالمياً (يتطلب اشتراكاً) — تُفتح الصفحة ويُنسخ الاستعلام",u:"https://www.proquest.com/",manual:1},
 {n:"EBSCO Open Dissertations",s:"أطروحات مفتوحة من جامعات متعددة",u:"https://opendissertations.org/",manual:1},
 {n:"EThOS — British Library",s:"فهرس رسائل الدكتوراه البريطانية",u:"https://ethos.bl.uk/",manual:1},
 {n:"CORE",s:"أرشيف أبحاث مفتوح يضم رسائل وأطروحات جامعية",u:()=>"https://core.ac.uk/search?q="+enc(Q())},
 {n:"BASE — Bielefeld",s:"محرك بحث أوروبي للأبحاث والرسائل العلمية",u:()=>"https://www.base-search.net/Search/Results?lookfor="+enc(Q())},
 {n:"WorldCat",s:"فهرس عالمي للكتب والرسائل لدى جامعات العالم",u:()=>"https://search.worldcat.org/search?q="+enc(Q())},
 {n:"OpenAIRE",s:"بوابة الأبحاث المفتوحة الأوروبية",u:()=>"https://explore.openaire.eu/search?keyword="+enc(Q())}
]},
{n:"🔬 مجلات ودوريات محكّمة",items:[
 {n:"ScienceDirect",s:"Elsevier — آلاف المجلات المحكّمة",u:()=>"https://www.sciencedirect.com/search?qs="+enc(Q())},
 {n:"Springer Link",s:"مجلات وكتب Springer Nature",u:()=>"https://link.springer.com/search?query="+enc(Q())},
 {n:"Wiley Online Library",s:"مجلات Wiley المحكّمة",u:()=>"https://onlinelibrary.wiley.com/action/doSearch?AllField="+enc(Q())},
 {n:"SAGE Journals",s:"العلوم الاجتماعية والإدارة والتعليم",u:()=>"https://journals.sagepub.com/action/doSearch?AllField="+enc(Q())},
 {n:"Taylor & Francis",s:"مجلات T&F المحكّمة",u:()=>"https://www.tandfonline.com/action/doSearch?AllField="+enc(Q())},
 {n:"Emerald Insight",s:"إدارة الأعمال وعلوم المكتبات",u:()=>"https://www.emerald.com/insight/search?q="+enc(Q())},
 {n:"MDPI",s:"دوريات مفتوحة الوصول المحكّمة",u:()=>"https://www.mdpi.com/search?q="+enc(Q())},
 {n:"JSTOR",s:"أرشيف أكاديمي كبير للمجلات والرسائل",u:()=>"https://www.jstor.org/action/doBasicSearch?Query="+enc(Q())},
 {n:"SSRN",s:"أبحاث أولية في الإدارة والاقتصاد",u:()=>"https://papers.ssrn.com/sol3/results.cfm?txtKey_Words="+enc(Q())},
 {n:"PubMed",s:"الأدب الصحي والطبي",u:()=>"https://pubmed.ncbi.nlm.nih.gov/?term="+enc(Q())},
 {n:"IEEE Xplore",s:"الهندسة والحوسبة والإلكترونيات",u:()=>"https://ieeexplore.ieee.org/search/searchresult.jsp?queryText="+enc(Q())},
 {n:"ERIC",s:"علوم التربية والتعليم",u:()=>"https://eric.ed.gov/?q="+enc(Q())},
 {n:"arXiv",s:"أبحاث ما قبل النشر (رياضيات/حوسبة/فيزياء)",u:()=>"https://arxiv.org/search/?query="+enc(Q())+"&searchtype=all"}
]},
{n:"🗄️ قواعد بيانات وفهارس محكّمة",items:[
 {n:"Scopus",s:"أكبر قاعدة اقتباسات علمية (يتطلب اشتراكاً)",u:()=>"https://www.scopus.com/results/results.uri?st1="+enc(Q())+"&src=s&sot=b&sdt=b"},
 {n:"Web of Science",s:"Clarivate — تُفتح صفحة البحث ويُنسخ الاستعلام",u:"https://www.webofscience.com/wos/woscc/basic-search",manual:1},
 {n:"Semantic Scholar",s:"محرك بحث ذكي من Allen AI",u:()=>"https://www.semanticscholar.org/search?q="+enc(Q())},
 {n:"Crossref",s:"سجل عالمي لبيانات النشر وأرقام DOI",u:()=>"https://search.crossref.org/?q="+enc(Q())},
 {n:"OpenAlex",s:"فهرس مفتوح للأعمال العلمية والاقتباسات",u:"https://openalex.org/",manual:1},
 {n:"DOAJ",s:"دليل المجلات المفتوحة المحكّمة",u:"https://doaj.org/",manual:1}
]},
{n:"🌍 مصادر عربية",items:[
 {n:"شمعة SHAMAA",s:"المركز العربي لتوثيق المعارف — رسائل وبحوث عربية",u:"https://www.shamaa.org/",manual:1},
 {n:"شمعة عبر Google",s:"site:shamaa.org داخل جوجل",u:()=>siteQ("shamaa.org")},
 {n:"دار المنظومة",s:"منصة المجلات والرسائل العربية",u:"https://www.mandumah.com/",manual:1},
 {n:"المنظومة عبر Google",s:"site:mandumah.com داخل جوجل",u:()=>siteQ("mandumah.com")},
 {n:"مستودع الملك سعود",s:"رسائل الدراسات العليا — جامعة الملك سعود",u:"https://era.ksu.edu.sa/",manual:1},
 {n:"جوجل بالعربية",s:"بحث عربي مقيّد بـ«رسالة دكتوراه»",u:()=>"https://www.google.com/search?q="+enc(Q()+(hasAr(Q())?" رسالة دكتوراه":" dissertation"))+"&lr=lang_ar"+cdrP()}
]}];
function destHtml(){return GROUPS.map((g,gi)=>`<div class="gh">${g.n}</div><div class="dests">${g.items.map((d,ii)=>`
 <div class="dest"><b>${esc(d.n)}</b><small>${esc(d.s)}</small>
 <div class="row" style="margin:2px 0 0"><button class="mini" data-go="${gi}:${ii}">${d.manual?"فتح + نسخ الاستعلام ↗":"فتح البحث ↗"}</button></div></div>`).join("")}</div>`).join("")}
function srRow(x,i){return `<div class="rule"><span class="badge wr">${esc(x.db||"أخرى")}</span>
 <div>${esc(x.q||"بلا استعلام")}<small>${esc(x.date||"")}${(x.ylo||x.yhi)?" · السنوات: "+esc(x.ylo||"…")+"–"+esc(x.yhi||"…"):""}${x.n?" · النتائج: "+esc(x.n):""}${x.note?" · "+esc(x.note):""}</small></div>
 <button class="btn del" data-srdel="${i}">حذف</button></div>`}
function vSearch(){
 const rows=S.sr.length?S.sr.map(srRow).join(""):`<div class="empty">لم تُسجَّل أي عملية بحث بعد. سجّل كل عملية لتُخرِجها في فصل المنهجية.</div>`;
 return `<div class="card"><h2>مولّد الاستعلام الأكاديمي</h2>
 <p class="hint">اكتب كلمات الموضوع/المتغيرات، ثم افتح أي قاعدة بيانات لعرض النتائج جاهزة. اختر «رسائل دكتوراة» لتوسيع مصادر الدراسات السابقة المحكّمة المرتبطة بموضوعك.</p>
 <label>كلمات البحث / عبارة الاستعلام</label><textarea id="sq" placeholder="مثال: التحول الرقمي وأداء الموظفين في القطاع المالي">${esc(F.sq)}</textarea>
 <div class="grid">
  <div><label>نوع المصدر المطلوب</label><select id="stype">${[["all","الكل"],["thesis","رسائل دكتوراة (Theses)"],["article","مقالات محكّمة فقط"]].map(o=>`<option value="${o[0]}" ${F.stype===o[0]?"selected":""}>${o[1]}</option>`).join("")}</select></div>
  <div><label>لغة النتائج</label><select id="slang">${[["all","الكل"],["ar","عربي"],["en","إنجليزي"]].map(o=>`<option value="${o[0]}" ${F.slang===o[0]?"selected":""}>${o[1]}</option>`).join("")}</select></div>
  <div><label>من سنة</label><input id="sylo" type="number" inputmode="numeric" placeholder="2020" value="${esc(F.sylo)}"></div>
  <div><label>إلى سنة</label><input id="syhi" type="number" inputmode="numeric" placeholder="2026" value="${esc(F.syhi)}"></div>
 </div>
 <div class="row"><button class="btn" id="copq">📋 نسخ الاستعلام المركّب</button><span class="hint" style="margin:0">الاستعلام: <b id="qprev">${esc(Q()||"—")}</b></span></div></div>
 <div class="card"><h2>بوّابات البحث المعتمدة</h2><p class="hint">افتح أي قاعدة لبدء البحث مباشرة. القواعد التي تتطلب اشتراكاً تُفتح صفحتها ويُنسخ الاستعلام لتلصقه بنفسك.</p>${destHtml()}</div>
 <div class="card"><h2>سجل استراتيجية البحث</h2><p class="hint">وثّق كل عملية بحث (القاعدة، الاستعلام، التاريخ، السنوات، عدد النتائج) — يُستخرج مباشرة إلى فصل المنهجية.</p>
 <div class="grid">
  <div><label>قاعدة البيانات / المحرك</label><select id="lgdb">${SRDB.map(d=>`<option>${esc(d)}</option>`).join("")}</select></div>
  <div><label>تاريخ البحث</label><input type="date" id="lgdt" value="${new Date().toISOString().slice(0,10)}"></div>
  <div><label>عدد النتائج</label><input type="number" inputmode="numeric" id="lgn"></div>
  <div><label>من سنة</label><input type="number" inputmode="numeric" id="lgy1"></div>
  <div><label>إلى سنة</label><input type="number" inputmode="numeric" id="lgy2"></div>
 </div>
 <label>نص الاستعلام الكامل</label><textarea id="lgq" placeholder="العبارة كما أدخلتها في القاعدة"></textarea>
 <label>ملاحظات (الفلاتر، نوع البحث، ملاحظات المشرف…)</label><textarea id="lgnt"></textarea>
 <div class="row"><button class="btn" id="lgadd">＋ تسجيل عملية بحث</button>
 <button class="btn sec" id="expSrW">Word</button><button class="btn sec" id="expSrC">CSV</button></div>
 <div style="margin-top:10px">${rows}</div></div>`;
}

function vMx(){return `<div class="card"><h2>مصفوفة الاتساق</h2><p class="hint">اربط الفجوة بالسؤال والهدف والفرض والأداة والاختبار والنتيجة والتوصية.</p>
 <div class="row"><button class="btn" data-add="mx">إضافة صف</button>
 <button class="btn sec" id="expMxW">Word</button><button class="btn sec" id="expMxC">Excel/CSV</button></div></div>
 <div id="list-mx">${S.mx.length?S.mx.map((x,i)=>{const open=!!uiOpen["mx"+i],miss=MF.filter(f=>!String(x[f[0]]||"").trim()).length;
  return `<div class="card"><div class="row"><h3 style="margin:0;flex:1">${esc(x.q||"صف بلا سؤال")} <span class="badge ${x.qt==="d"?"wr":"ok"}">${x.qt==="d"?"وصفي":"اختباري"}</span>${miss?`<span class="badge wr">ناقص ${miss}</span>`:""}</h3>
  <button class="btn sec" data-tog="mx${i}">${open?"إغلاق":"فتح"}</button>
  <button class="btn sec" data-dup="mx" data-i="${i}">تكرار</button>
  <button class="btn del" data-del="mx" data-i="${i}">حذف</button></div>
  ${open?`<div class="grid">${selF("mx",i,"qt","نوع السؤال",[["t","اختباري (له فرض)"],["d","وصفي (بلا فرض)"]],x.qt)}${MF.map(f=>fld("mx",i,f[0],f[1],f[2],x[f[0]])).join("")}</div>`:""}</div>`}).join(""):`<div class="empty">لا صفوف بعد. ابدأ بالزر أعلاه.</div>`}</div>`}

function vTrash(){const tyN={studies:"دراسة",refs:"مرجع",mx:"صف مصفوفة"};
 return `<div class="card"><h2>سلة المحذوفات</h2><p class="hint">العناصر المحذوفة من هذا المشروع (حتى 50 عنصراً). استعيدها متى شئت.</p>
 ${S.trash.length?`<div class="row"><button class="btn del" id="tempty">تفريغ السلة</button></div>`+
 S.trash.map((x,i)=>{const nm=x.it.author||x.it.title||x.it.cite||x.it.q||"بلا عنوان";
  return `<div class="rule"><span class="badge wr">${tyN[x.ty]||"عنصر"}</span><div>${esc(nm)}<small>حُذف: ${fmtT(x.t)}</small></div>
  <button class="btn sec" data-res="${i}">استعادة</button><button class="btn del" data-purge="${i}">حذف نهائي</button></div>`}).join("")
 :`<div class="empty">السلة فارغة.</div>`}</div>`}

function vBackup(){const pr=P();
 const snaps=pr.snaps.length?pr.snaps.map((s,i)=>`<div class="rule"><span class="badge ok">لقطة</span><div>${esc(s.label)}<small>${fmtT(s.t)}</small></div>
  <button class="btn sec" data-sres="${i}">استعادة</button><button class="btn del" data-sdel="${i}">حذف</button></div>`).join("")
 :`<div class="empty">لا لقطات بعد.</div>`;
 return `<div class="card"><h2>نسخة المشروع الحالي</h2><p class="hint">البيانات محفوظة في هذا المتصفح فقط. آخر تصدير: ${pr.lastExp?fmtT(pr.lastExp):"لم يحدث بعد"}.</p>
 <div class="row"><button class="btn" id="expp">تصدير المشروع (JSON)</button>
 <label class="btn sec" style="margin:0;display:inline-block;color:var(--acc)">استيراد مشروع<input type="file" id="impp" accept=".json" hidden></label>
 <button class="btn sec" id="expall">تصدير كل المشاريع</button></div>
 <p class="hint">لا تولّد هذه الأداة دراسات أو مراجع تلقائياً: أدخل كل مرجع من مصدره. (يمكن جلب بيانات DOI الرسمية عبر فحص المراجع.)</p></div>
 <div class="card"><h2>لقطات محفوظة (حتى 5)</h2><p class="hint">اللقطة صورة كاملة لبيانات المشروع في لحظة. الاستعادة تحفظ وضعك الحالي تلقائياً كأحدث لقطة قبل الاستبدال.</p>
 <div class="row"><button class="btn" id="snown">حفظ لقطة الآن</button></div>${snaps}</div>
 <div class="card"><h2>منطقة الخطر</h2><div class="row"><button class="btn del" id="rst">مسح كل المشاريع والبيانات</button></div></div>`}

const TABS=["📊 الملخص والتحقق","🧾 ملف المشروع","🗂️ متتبع الهيكل","📚 الدراسات السابقة","🔗 سجل المراجع","🔎 فحص المراجع","🔍 البحث الأكاديمي","🧩 مصفوفة الاتساق","🗑️ سلة المحذوفات","💾 النسخ والاستيراد","🤖 المولّد الآلي","🏠 البداية"];
const VIEWS=[vSummary,vProfile,vStruct,vStudies,vRefs,vVerify,vSearch,vMx,vTrash,vBackup,vAuto,vHome];
function render(){
 document.getElementById("psel").innerHTML=Object.values(DB.projects).map(p=>`<option value="${p.id}" ${p.id===DB.cur?"selected":""}>${esc(p.name)}</option>`).join("");
 {const MAIN=[HOME,PATH,3,4,10,9],inMain=MAIN.includes(tab),all=F.more||!inMain,ids=all?MAIN.concat(TABS.map((t,i)=>i).filter(i=>!MAIN.includes(i))):MAIN;
  document.getElementById("nav").innerHTML=ids.map(i=>`<button role="tab" aria-selected="${i===tab}" data-tab="${i}">${TABS[i]}</button>`).join("")+(inMain?`<button id="navmore" class="mini">${F.more?"▲ أقل":"⚙ المزيد"}</button>`:"")}
 document.getElementById("main").innerHTML=VIEWS[tab]();}

/* ===== الأحداث ===== */
document.addEventListener("click",e=>{
 const t=e.target.closest("button,[data-tab]");if(!t)return;
 if(t.dataset.tab!==undefined){tab=+t.dataset.tab;render();scrollTo(0,0)}
 else if(t.dataset.add){const l=t.dataset.add,o=l==="studies"?{axis:"iv",typ:"j"}:l==="refs"?{cat:"A",lang:"en"}:{qt:"t"};
  S[l].unshift(o);
  const n={};Object.keys(uiOpen).forEach(k=>{if(k.startsWith(l)){const i=+k.slice(l.length);n[l+(i+1)]=uiOpen[k]}else n[k]=uiOpen[k]});
  n[l+"0"]=true;uiOpen=n;save();render()}
 else if(t.dataset.dup){const l=t.dataset.dup,i=+t.dataset.i;S[l].splice(i+1,0,cl(S[l][i]));
  const n={};Object.keys(uiOpen).forEach(k=>{if(k.startsWith(l)){const j=+k.slice(l.length);n[l+(j>i?j+1:j)]=uiOpen[k]}else n[k]=uiOpen[k]});
  n[l+(i+1)]=true;uiOpen=n;save();render();toast("أُنشئت نسخة للتعديل")}
 else if(t.dataset.tog){uiOpen[t.dataset.tog]=!uiOpen[t.dataset.tog];render()}
 else if(t.dataset.del){if(confirm("نقل العنصر إلى سلة المحذوفات؟")){const l=t.dataset.del,i=+t.dataset.i;
  P().trash.unshift({ty:l,it:cl(S[l][i]),t:Date.now()});if(P().trash.length>50)P().trash.length=50;
  S[l].splice(i,1);uiOpen={};save();render();toast("نُقل إلى السلة ويمكن استعادته")}}
 else if(t.dataset.res!==undefined){const it=S.trash.splice(+t.dataset.res,1)[0];S[it.ty].unshift(cl(it.it));uiOpen={};save();render();toast("تمت الاستعادة")}
 else if(t.dataset.purge!==undefined){if(confirm("حذف نهائي لا يمكن التراجع عنه؟")){S.trash.splice(+t.dataset.purge,1);save();render()}}
 else if(t.dataset.ver!==undefined){verifyRef(+t.dataset.ver)}
 else if(t.dataset.srdel!==undefined){S.sr.splice(+t.dataset.srdel,1);save();render()}
 else if(t.dataset.adddoi!==undefined){const r=S.refs[+t.dataset.adddoi];if(r&&r.v&&r.v.sugg){r.doi=r.v.sugg;delete r.v.sugg;save();render();toast("اعتُمد الـ DOI المقترح — أعد الفحص للتأكيد")}}
 else if(t.dataset.applyv!==undefined){const r=S.refs[+t.dataset.applyv],v=r&&r.v;if(v){if(v.ct)r.ttl=v.ct;if(v.cy)r.year=v.cy;if(v.j)r.jr=v.j;if(v.aut)r.aut=v.aut;if(v.sugg)r.doi=v.sugg;if(v.oa==="closed"||!r.peer)r.peer=true;save();render();toast("اعتُمدت بيانات السجل الرسمي على المرجع")}}
 else if(t.dataset.go){const p=t.dataset.go.split(":"),d=GROUPS[+p[0]]&&GROUPS[+p[0]].items[+p[1]];if(!d)return;
  const q=Q();
  if(!q&&!d.manual){toast("اكتب كلمات البحث أولاً",1);return}
  const url=typeof d.u==="function"?d.u():d.u;
  if(d.manual&&q)copy(q);
  window.open(url,"_blank","noopener");
  if(d.manual&&q)toast("نُسخ الاستعلام — الصقه في صفحة القاعدة بعد فتحها")}
 else if(t.id==="tempty"){if(confirm("تفريغ السلة نهائياً؟")){S.trash=[];save();render()}}
 else if(t.id==="expp"){dl("thesis-desk-project.json",JSON.stringify(Object.assign(cl(P()),{snaps:[]}),null,1),"application/json");toast("تم تصدير المشروع")}
 else if(t.id==="expall"){dl("thesis-desk-all.json",JSON.stringify(DB,null,1),"application/json");toast("تم تصدير كل المشاريع")}
 else if(t.id==="snown"){snapshot("")}
 else if(t.id==="adddoi"){addByDoi()}
 else if(t.id==="vgo"){const q=document.getElementById("vq").value,o=document.getElementById("vout");
  o.innerHTML='<p class="hint">جارٍ الفحص عبر Crossref وOpenAlex…</p>';
  coreCheck(Object.assign(parseQ(q),{year:0})).then(v=>{o.innerHTML=verdictHtml(v,q)})
   .catch(()=>{o.innerHTML='<div class="rule" style="border-top:0"><span class="badge fl">تعذّر</span><div>تعذّر الوصول إلى قواعد البيانات — تأكد من اتصال الإنترنت.</div></div>'})}
 else if(t.id==="vall"){verifyAll()}
 else if(t.id==="copq"){const q=Q();if(!q)return toast("اكتب كلمات البحث أولاً",1);copy(q)?toast("نُسخ الاستعلام"):toast("تعذّر النسخ — حدّد النص يدوياً",1)}
 else if(t.id==="lgadd"){const g=id=>document.getElementById(id),q=g("lgq").value.trim();
  if(!q)return toast("اكتب نص الاستعلام أولاً",1);
  S.sr.unshift({db:g("lgdb").value,date:g("lgdt").value||new Date().toISOString().slice(0,10),q:q,ylo:g("lgy1").value,yhi:g("lgy2").value,n:g("lgn").value,note:g("lgnt").value});
  save();render();toast("سُجّلت عملية البحث")}
 else if(t.dataset.sres!==undefined){const i=+t.dataset.sres,pr=P(),snap=pr.snaps[i];
  if(!snap||!confirm("استعادة هذه اللقطة؟ سيُحفظ وضعك الحالي تلقائياً قبل الاستبدال."))return;
  pr.snaps.unshift({t:Date.now(),label:"قبل الاستعادة",d:cl({p:pr.p,sec:pr.sec,studies:pr.studies,refs:pr.refs,mx:pr.mx,sr:pr.sr})});
  if(pr.snaps.length>5)pr.snaps.length=5;
  Object.assign(pr,cl(snap.d));save();render();toast("تمت الاستعادة")}
 else if(t.dataset.sdel!==undefined){P().snaps.splice(+t.dataset.sdel,1);save();render()}
 else if(t.id==="newp"){const n=prompt("اسم المشروع الجديد:","رسالة جديدة");if(n&&n.trim()){
  const pr=blankP(n.trim());DB.projects[pr.id]=pr;DB.cur=pr.id;S=P();uiOpen={};F.stQ="";F.stAx="";F.rfQ="";F.rfCat="";tab=HOME;save();render();toast("أُنشئ مشروع جديد")}}
 else if(t.id==="renp"){const n=prompt("الاسم الجديد:",P().name);if(n&&n.trim()){P().name=n.trim();save();render()}}
 else if(t.id==="delp"){if(confirm('حذف المشروع "'+P().name+'" نهائياً؟ تأكد من تصدير نسخة أولاً.')){
  delete DB.projects[DB.cur];const k=Object.keys(DB.projects);
  if(k.length)DB.cur=k[0];else{const pr=blankP();DB.projects[pr.id]=pr;DB.cur=pr.id}
  S=P();uiOpen={};tab=HOME;save();render()}}
 else if(t.id==="thm"){thm=thm===""?"light":thm==="light"?"dark":"";try{localStorage.setItem(TKEY,thm)}catch(e){}applyTheme()}
 else if(t.id==="expStruct"){exportWord("structure.doc","هيكل الرسالة وتقدمها – "+P().name,structBody())}
 else if(t.id==="expStW"){const l=stFiltered().map(a=>a[0]);l.length?exportWord("studies.doc","جدول الدراسات السابقة – "+P().name,studiesTable(l)):toast("لا توجد دراسات للتصدير",1)}
 else if(t.id==="expStC"){const l=stFiltered().map(a=>a[0]);if(!l.length)return toast("لا توجد دراسات للتصدير",1);
  const head=["#","المحور","نوع المصدر"].concat(SF.map(f=>f[1])).concat(["المجلة/الجهة","DOI","التصنيف","قاعدة البيانات","المنهج"]);
  exportRows("studies.csv",head,l.map((x,i)=>[i+1,AX[x.axis]||"",TYPN[x.typ]||""].concat(SF.map(f=>x[f[0]]||"")).concat([x.jr||"",x.doi||"",x.qu||"",x.db||"",x.meth||""])))}
 else if(t.id==="expRfW"){const l=rfFiltered().map(a=>a[0]);l.length?exportWord("references.doc","سجل المراجع – "+P().name,refsBody(l)):toast("لا مراجع للتصدير",1)}
 else if(t.id==="expRfC"){const l=rfFiltered().map(a=>a[0]);if(!l.length)return toast("لا مراجع للتصدير",1);
  exportRows("references.csv",["#","الفئة","التوثيق","العنوان","المؤلفون","المجلة/الجهة","السنة","اللغة","DOI/رابط","محكّم","حالة الفحص","تبرير"],
   l.map((x,i)=>[i+1,{A:"أ",B:"ب",C:"ج"}[x.cat]||"",x.cite||"",x.ttl||"",x.aut||"",x.jr||"",x.year||"",x.lang==="ar"?"عربي":"إنجليزي",x.doi||"",x.peer?"نعم":"",VERST(x),x.just||""]))}
 else if(t.id==="expMxW"){S.mx.length?exportWord("matrix.doc","مصفوفة الاتساق – "+P().name,mxBody(S.mx)):toast("المصفوفة فارغة",1)}
 else if(t.id==="expMxC"){if(!S.mx.length)return toast("المصفوفة فارغة",1);
  exportRows("matrix.csv",["#","نوع السؤال"].concat(MF.map(f=>f[1])),S.mx.map((x,i)=>[i+1,x.qt==="d"?"وصفي":"اختباري"].concat(MF.map(f=>x[f[0]]||""))))}
 else if(t.id==="expSrW"){S.sr.length?exportWord("search-strategy.doc","استراتيجية البحث الأكاديمي – "+P().name,srBody()):toast("سجل البحث فارغ",1)}
 else if(t.id==="expSrC"){if(!S.sr.length)return toast("سجل البحث فارغ",1);
  exportRows("search-strategy.csv",["#","قاعدة البيانات","التاريخ","الاستعلام","من سنة","إلى سنة","عدد النتائج","ملاحظات"],S.sr.map((x,i)=>[i+1,x.db||"",x.date||"",x.q||"",x.ylo||"",x.yhi||"",x.n||"",x.note||""]))}
 else if(t.id==="expVW"){S.refs.length?exportWord("references-verification.doc","تقرير فحص صحة المراجع – "+P().name,verBody()):toast("لا مراجع للتصدير",1)}
 else if(t.id==="aggo"){runAuto()}
 else if(t.id==="agall"){agallAct()}
 else if(t.dataset.agone!==undefined){agoneAct(+t.dataset.agone)}
 else if(t.id==="agadd"){agAdd()}
 else if(t.id==="rexpW"){(S.studies.length||S.refs.length)?exportWord("literature-review.doc","تقرير المراجعة الأدبية – "+P().name,litBody()+bibBody()):toast("لا توجد دراسات أو مراجع بعد",1)}
 else if(t.id==="rexpM"){dl("literature-review.md","\ufeff# تقرير المراجعة الأدبية – "+P().name+"\n\n"+litMdBody()+bibMd(),"text/markdown;charset=utf-8");toast("تم تصدير literature-review.md")}
 else if(t.id==="skW"){exportWord("thesis-skeleton.doc","هيكل الرسالة – "+P().name,skelBody())}
 else if(t.id==="skM"){dl("thesis-skeleton.md","\ufeff"+skelMd(),"text/markdown;charset=utf-8");toast("تم تصدير thesis-skeleton.md")}
 else if(t.id==="elq1"){elqAct(elq1)}
 else if(t.id==="elq2"){elqAct(elq2)}
 else if(t.id==="elq3"){elqAct(elq3)}
 else if(t.id==="elgo"){llmGo()}
 else if(t.id==="apitest"){llmTest()}
 else if(t.id==="hmgo"){hmAnalyze()}
 else if(t.dataset.hmadopt!==undefined){const g=sugTitles(S.p,parseTitle(S.p.title))[+t.dataset.hmadopt];if(g){S.p.title=g.t;save();render();toast("اعتُمد العنوان — اضغط «حلّل العنوان» لتحديث المتغيرات")}}
 else if(t.id==="hmsearch"){if(navigator.onLine===false){toast("لا يوجد اتصال بالإنترنت: البحث يحتاج إنترنت، وبقية الوظائف تعمل دون اتصال",1);return}const x=document.getElementById("agx");F.ag=(x&&x.value.trim())||hmEn();save();tab=10;render();runAuto()}
 else if(t.id==="hmgap"){hmGap()}
 else if(t.id==="elsave"){llmSave()}
 else if(t.id==="rst"){if(confirm("سيُمسح كل شيء من هذا المتصفح (كل المشاريع). هل صدّرت نسخة؟")){try{localStorage.removeItem(KEY)}catch(e){}location.reload()}}
});
document.addEventListener("input",e=>{const id=e.target.id;
 if(id==="stQ"){F.stQ=e.target.value;clearTimeout(window._d1);window._d1=setTimeout(()=>{const el=document.getElementById("list-studies");if(el)el.innerHTML=studiesHtml()},250)}
 else if(id==="rfQ"){F.rfQ=e.target.value;clearTimeout(window._d2);window._d2=setTimeout(()=>{const el=document.getElementById("list-refs");if(el)el.innerHTML=refsHtml()},250)}
 else if(id==="sq"||id==="stype"||id==="slang"||id==="sylo"||id==="syhi"){F[id]=e.target.value;
  const q=document.getElementById("qprev");if(q)q.textContent=Q()||"—"}
 else if(id==="agx"||id==="agto"||id==="agn"||id==="elpr"){F[id]=e.target.value}});
document.addEventListener("change",e=>{
 const t=e.target;
 if(t.id==="psel"){DB.cur=t.value;S=P();uiOpen={};F.stQ="";F.stAx="";F.rfQ="";F.rfCat="";save();render();return}
 if(t.id==="stAx"){F.stAx=t.value;const el=document.getElementById("list-studies");if(el)el.innerHTML=studiesHtml();return}
 if(t.id==="rfCat"){F.rfCat=t.value;const el=document.getElementById("list-refs");if(el)el.innerHTML=refsHtml();return}
 if(t.dataset.agsel!==undefined){const o=AG[+t.dataset.agsel];if(o){if(t.checked)AGS[o.doi]=1;else delete AGS[o.doi]}agcnt();return}
 if(t.id==="apib"||t.id==="apim"){apiRead();return}
 const l=t.dataset.l;if(!l)return;
 const v=t.type==="checkbox"?t.checked:t.value,i=t.dataset.i,k=t.dataset.k;
 if(l==="meta"){P().name=v;save();render();return}
 if(l==="p")S.p[k]=v;else if(l==="sec"){S.sec[i]=S.sec[i]||{};S.sec[i][k]=v}else if(l==="studies"||l==="refs"||l==="mx")S[l][+i][k]=v;
 save();
 if(l!=="sec"&&["axis","year","cat","minY","target","med","qt","author","cite","q","doi","peer","lang","typ","ttl"].includes(k)&&tab!==HOME)render();
});
/* استيراد الملفات */
document.addEventListener("change",e=>{
 const t=e.target;
 if(t.id!=="impp")return;
 const f=t.files[0];if(!f)return;const r=new FileReader();
 r.onload=()=>{try{const d=JSON.parse(r.result);
  if(d&&d.projects){if(!confirm("سيُدمج الملف مع مشاريعك (المعرّف نفسه يُستبدل). متابعة؟"))return;
   Object.keys(d.projects).forEach(k=>{DB.projects[k]=d.projects[k]});
   DB.cur=(d.cur&&DB.projects[d.cur])?d.cur:Object.keys(DB.projects)[0]}
  else if(d&&d.p){const id=(d.id&&!DB.projects[d.id])?d.id:uid();
   DB.projects[id]=Object.assign(blankP(),d,{id:id,snaps:[],trash:d.trash||[]});DB.cur=id}
  else throw 0;
  fixProjs(DB);S=P();uiOpen={};tab=HOME;save();render();toast("تم الاستيراد بنجاح")}
 catch(x){toast("الملف غير صالح: اختر ملفًا صدّرته من هذه الأداة.",1)}};
 r.readAsText(f);t.value=""});

/* إضافة مرجع تلقائياً عبر DOI */
async function addByDoi(){
 const q=prompt("الصق رقم DOI (مثال: 10.1016/j.chb.2023.109412) أو عنوان البحث:");
 if(!q||!q.trim())return;
 const p=parseQ(q);
 toast("جارٍ جلب بيانات السجل الرسمي…");
 try{
  let m=null;
  if(p.doi){const r=await jget("https://api.crossref.org/works/"+segEnc(p.doi));m=r.message}
  else{const r=await jget("https://api.crossref.org/works?query.bibliographic="+enc(p.title)+"&rows=3");m=r.message&&r.message.items&&r.message.items[0]}
  if(!m)return toast("لم يُعثر على المرجع في Crossref — تحقق من الرقم/العنوان",1);
  const au=(m.author||[]).map(a=>a.family?(a.family+", "+String(a.given||"").split(/\s+/).map(w=>w?w[0]+".":"").join(" ")):(a.name||"")).filter(Boolean).join(", ");
  const y=crYear(m)||"";
  const tt=(m.title&&m.title[0])||"";
  const jr=(m["container-title"]&&m["container-title"][0])||m.publisher||"";
  let cite=au||"?";
  cite+=(y?" ("+y+"). ":" (بلا تاريخ). ")+tt+". ";
  if(m["container-title"]&&m["container-title"][0])cite+=m["container-title"][0];
  if(m.volume)cite+=", "+m.volume;if(m.issue)cite+="("+m.issue+")";if(m.page)cite+=", "+m.page;
  cite+=". "+(m.DOI?"https://doi.org/"+m.DOI:"");
  const lang=hasAr(tt)?"ar":"en";
  const ok=(crYear(m)>=num(S.p.minY))?"A":"B";
  S.refs.unshift({cat:ok,lang:lang,cite:cite.replace(/\s+/g," ").trim(),ttl:tt,aut:au,year:y,jr:jr,doi:m.DOI||p.doi,peer:true,just:"",v:{t:Date.now(),ok:"ok",msg:"✓ جُلب من السجل الرسمي في Crossref",src:"Crossref",ct:tt,cy:crYear(m),j:jr,typ:m.type,cited:m["is-referenced-by-count"],doi:m.DOI||p.doi}});
  save();render();toast("أُضيف المرجع من Crossref"+(m.DOI?' (DOI: '+m.DOI+')':""));
 }catch(e){toast(e&&e.http===404?"هذا الـ DOI غير موجود في Crossref":"تعذّر الجلب — تأكد من الإنترنت والصيغة",1)}
}

/* ===== المولّد الآلي: بحث آلي + فحص + تجميع + توليد نص ===== */
let AG=[],AGS={},AGBUSY=false;
let apiCfg={base:"http://localhost:11434",model:"qwen2.5:3b"},OLM={models:[],ok:null};
try{const j=JSON.parse(localStorage.getItem("td-llm")||"null");if(j&&j.base)apiCfg=Object.assign(apiCfg,{base:j.base,model:j.model||apiCfg.model})}catch(e){}
try{localStorage.removeItem("td-api")}catch(e){} /* حذف أي مفتاح API قديم كان محفوظاً من النسخة السابقة */
function saveApi(){try{localStorage.setItem("td-llm",JSON.stringify({base:apiCfg.base,model:apiCfg.model}))}catch(e){}}
const md=s=>String(s==null?"":s);
function abiToText(o){const idx=o&&o.abstract_inverted_index;if(!idx)return"";
 const arr=[];Object.keys(idx).forEach(w=>{(idx[w]||[]).forEach(p=>{arr[p]=w})});
 let s="";for(let i=0;i<arr.length;i++){const w=arr[i];if(w===undefined)continue;s+=(s?" ":"")+w;if(s.length>1500)break}
 return s.trim()}
function oaType(t){return t==="dissertation"?"d":(t==="article"||t==="review")?"j":t==="conference"?"c":t==="report"?"r":(t==="book"||t==="book-chapter")?"o":""}
function oaAuth(o){return((o.authorships||[]).slice(0,20).map(a=>a.author&&a.author.display_name).filter(Boolean).join("; "))}
function oaVenue(o){return (o.primary_location&&o.primary_location.source&&o.primary_location.source.display_name)||(o.host_venue&&o.host_venue.display_name)||""}
function oaApa(o){const au=(o.authorships||[]).slice(0,20).map(a=>{const nm=(a.author&&a.author.display_name)||"";const p=nm.split(/[\s,]+/).filter(Boolean);let last=p.pop()||"";if(!last)return "";if(p.length)last+=", "+p.map(w=>w[0]+".").join(" ");return last}).filter(Boolean).join(", ");
 let c=au||"?";c+=o.publication_year?" ("+o.publication_year+"). ":" (بلا تاريخ). ";
 c+=String(o.title||o.display_name||"بلا عنوان").replace(/\s+/g," ").trim()+". ";
 const vn=oaVenue(o);if(vn)c+=vn;
 const b=o.biblio||{};if(b.volume)c+=", "+b.volume;if(b.issue)c+="("+b.issue+")";if(b.first_page)c+=", "+b.first_page+(b.last_page?"–"+b.last_page:"");
 c=c.replace(/\s+,/g,",");c+="."+(o.doi?" https://doi.org/"+o.doi:"");return c.trim()}
function agQ(){const extra=String(F.ag||"").trim();
 const base=[extra,S.p.iv,S.p.dv,S.p.med,S.p.sector,((S.p.title||"").split(/[،,:؛]/)[0])].filter(x=>x&&String(x).trim());
 const words=[],push=s=>String(s).replace(/[^\p{L}\p{N}\s]/gu," ").split(/\s+/).forEach(w=>{w=w.trim();if(w.length>2&&words.indexOf(w)<0)words.push(w)});
 base.forEach(push);
 const latin=words.filter(w=>/[A-Za-z]/.test(w)),other=words.filter(w=>!/[A-Za-z]/.test(w));
 return latin.concat(other).slice(0,10).join(" ")}
function agIsAr(){return hasAr(agQ())}
function agQueries(){const cand=[],push=s=>{s=String(s==null?"":s).replace(/[^\p{L}\p{N}\s]/gu," ").replace(/\s+/g," ").trim();if(s.length>1&&cand.indexOf(s)<0)cand.push(s)};
 push(F.ag);push([S.p.iv,S.p.dv,S.p.med].filter(x=>x&&String(x).trim()).join(" "));push(String(S.p.title||"").split(/[،,:؛]/)[0]);
 return cand.slice(0,2)}
async function runAuto(){
 if(AGBUSY){toast("الجلب جارٍ بالفعل…");return}
 const qs=agQueries();if(!qs.length){toast("أدخل المتغيرات في «ملف المشروع» أو كلمات إضافية أولاً",1);return}
 AGBUSY=true;AG=[];AGS={};
 const w=document.getElementById("agwait");if(w)w.textContent="⏳ جارٍ البحث في OpenAlex…";
 const from=num((document.getElementById("agfrom")||{}).value)||num(S.p.minY)||2020;
 const to=num((document.getElementById("agto")||{}).value)||(new Date().getFullYear());
 const n=Math.max(4,Math.min(50,num((document.getElementById("agn")||{}).value)||12));
 const filt="from_publication_date:"+from+"-01-01,to_publication_date:"+to+"-12-31,has_doi:true";
 const urls=[];
 qs.forEach(q=>{const dq=q+(hasAr(q)?" رسالة دكتوراه":" dissertation");
  urls.push("https://api.openalex.org/works?search="+enc(q)+"&per-page="+n+"&sort=relevance_score:desc&filter="+enc(filt)+"");
  urls.push("https://api.openalex.org/works?search="+enc(dq)+"&per-page="+Math.max(4,Math.ceil(n/2))+"&sort=relevance_score:desc&filter="+enc(filt+",type:dissertation")+"")});
 const res=await Promise.allSettled(urls.slice(0,6).map(u=>jget(u,16000)));
 const seen={};
 res.forEach(r=>{if(r.status!=="fulfilled")return;((r.value&&r.value.results)||[]).forEach(o=>{if(!o||!o.doi)return;const dd=String(o.doi).replace(/^https?:\/\/(dx\.)?doi\.org\//i,"");if(!dd)return;o.doi=dd;const k=dd.toLowerCase();if(seen[k])return;seen[k]=1;AG.push(o)})});
 AG=AG.slice(0,40);AGBUSY=false;
 const el=document.getElementById("aglist");
 if(!AG.length){if(el)el.innerHTML='<div class="empty">لم يُعثر على نتائج — جرّب كلمات إنجليزية أدق أو وسّع السنوات.</div>';
  if(w)w.textContent="لم تُعثر نتائج.";agcnt();return}
 if(el)el.innerHTML=agHtml();
 if(w)w.textContent="وُجدت "+AG.length+" نتيجة — علّم المناسب ثم اضغط «أضف المحدّد».";
 agcnt()}
function agDup(o){const d=String(o.doi||"").toLowerCase(),strip=x=>String(x||"").toLowerCase().replace(/^https?:\/\/(dx\.)?doi\.org\//,"");
 return S.refs.some(r=>strip(r.doi)===d)||S.studies.some(s=>strip(s.doi)===d)}
function agRow(o,i){const dupe=agDup(o),ab=abiToText(o),cat=oaType(o.type),src=oaVenue(o),sel=AGS[o.doi]?"checked":"";
 return '<div class="rule"><div style="flex:0 0 34px">'+(dupe?'<span class="badge wr">موجود</span>':(o.is_retracted?'<span class="badge fl">مسحوب</span>':'<input type="checkbox" data-agsel="'+i+'" '+sel+'>'))+'</div><div>'+
  '<b>'+esc(o.title||o.display_name||"بلا عنوان")+'</b>'+
  '<small>'+esc(o.publication_year||"")+(oaVenue(o)?" · "+esc(oaVenue(o)):"")+(oaType(o.type)?" · "+(TYPN[oaType(o.type)]||""):"")+(o.cited_by_count!=null?" · اقتباسات: "+o.cited_by_count:"")+(o.open_access&&o.open_access.oa_status?" · وصول: "+esc(o.open_access.oa_status):"")+'</small>'+
  (o.doi?'<div class="mono">DOI: '+esc(o.doi)+'</div>':"")+
  (o.is_retracted?'<div class="mono">⛔ علم مسحوب (Retraction) — لن يُدرج</div>':"")+
  (abiToText(o)?'<details><summary class="mini">عرض المستخلص</summary><div class="mono">'+esc(abiToText(o))+'</div></details>':"")+
  '</div><div class="row">'+(o.is_retracted?"":'<button class="mini" data-agone="'+i+'">'+(AGS[o.doi]?"إلغاء التحديد":"تحديد")+'</button>')+'</div></div>'}
function agHtml(){return AG.map((o,i)=>agRow(o,i)).join("")}
function agcnt(){const c=document.getElementById("agcnt");if(c)c.textContent=String(Object.keys(AGS).length)}
function agRefFrom(o){const doi=String(o.doi||"").trim(),tt=String(o.title||o.display_name||"").replace(/\s+/g," ").trim(),c0=oaType(o.type),au=oaAuth(o),vn=oaVenue(o),y=o.publication_year||"",peer=(c0==="j"||c0==="c");
 S.studies.unshift({axis:"iv",typ:c0||"j",author:au,year:y,title:tt,goal:"",hyp:"",vars:"",field:S.p.sector||"",pop:"",sample:"",tools:"",find:"",agree:"",differ:"",jr:vn,doi:doi,qu:"",db:"OpenAlex",meth:"",ab:abiToText(o)});
 const ref={cat:(num(y)>=num(S.p.minY)&&peer)?"A":"B",lang:hasAr(tt)?"ar":"en",cite:oaApa(o),ttl:tt,aut:au,year:y,jr:vn,doi:doi,peer:peer,just:"",v:undefined};
 S.refs.unshift(ref);return ref}
async function agAdd(){
 const keys=Object.keys(AGS);if(!keys.length){toast("حدّد نتيجة واحدة على الأقل",1);return}
 const sel=AG.filter(o=>AGS[o.doi]&&!o.is_retracted);
 if(!sel.length){toast("لا عناصر صالحة — المسحوب يُستبعد تلقائياً",1);return}
 const added=[];sel.forEach(o=>{try{added.push(agRefFrom(o))}catch(e){}});
 AGS={};save();toast("أُدخلت "+added.length+" نتيجة (دراسة + مرجع) — جارٍ التمحيص الآلي…");
 const w=document.getElementById("agwait");
 let ok=0,wr=0,fl=0,nf=0,k=0,cap=Math.min(added.length,15);
 for(const r of added.slice(0,15)){
  k++;if(w)w.textContent="🩺 تمحيص "+k+" من "+cap+"…";
  try{const v=await coreCheck({doi:doiOf(r),title:r.ttl,cite:r.cite,year:r.year});
   if(String(v.msg||"").indexOf("اتصال")>=0){r.v=undefined;nf++}
   else{r.v=v;if(v.ok==="ok")ok++;else if(v.ret)fl++;else wr++}}
  catch(e){r.v=undefined;nf++}
  save()}
 render();
 toast("التمحيص: "+ok+" مطابق، "+(wr+fl)+" يحتاج مراجعة"+(nf?("، "+nf+" بلا إنترنت"):"")+" — راجع تبويب «فحص المراجع»")}
function litParts(){const order=["iv","med","dv","both"],used=order.filter(a=>S.studies.some(x=>x.axis===a));
 S.studies.forEach(x=>{if(used.indexOf(x.axis)<0)used.push(x.axis)});
 return used.map(a=>{const arr=S.studies.filter(x=>x.axis===a);
  return {a:a,ar:arr.filter(x=>hasAr((x.title||"")+(x.author||""))),en:arr.filter(x=>!hasAr((x.title||"")+(x.author||"")))}})}
function litBody(){let h="<p>عدد الدراسات المجمّعة: "+S.studies.length+" · عدد المراجع: "+S.refs.length+"</p>";
 litParts().forEach(g=>{h+="<h3>محور "+esc(AX[g.a]||g.a)+"</h3>";
  [["العربية",g.ar],["الأجنبية",g.en]].forEach(p=>{if(!p[1].length)return;
   h+="<h4>"+p[0]+" ("+p[1].length+")</h4><table><tr><th>#</th><th>الباحث</th><th>السنة</th><th>العنوان</th><th>المصدر</th><th>النوع</th><th>DOI</th><th>الهدف / أبرز ما ورد</th></tr>";
   p[1].forEach((x,i)=>{h+="<tr><td>"+(i+1)+"</td><td>"+esc(x.author)+"</td><td>"+esc(x.year)+"</td><td>"+esc(x.title)+"</td><td>"+esc(x.jr)+"</td><td>"+(TYPN[x.typ]||"")+"</td><td>"+esc(x.doi)+"</td><td>"+esc(String(x.goal||"").trim()||String(x.ab||"").slice(0,300))+"</td></tr>"});
   h+="</table>"})});
 if(!S.studies.length)h+="<p class=\"hint\">لا توجد دراسات سابقة بعد — استخدم «المولّد الآلي» لجلبها.</p>";
 h+="<h3>التعليق النقدي والفجوة البحثية</h3><p>تُكتب هنا المقارنة بين الدراسات (نقاط الاتفاق والاختلاف) والفجوة التي تسوّغ الدراسة الحالية.</p>";
 return h}
function litMdBody(){let m="عدد الدراسات: "+S.studies.length+" · المراجع: "+S.refs.length+"\n";
 litParts().forEach(g=>{m+="\n## محور "+(AX[g.a]||g.a)+"\n";
  [["العربية",g.ar],["الأجنبية",g.en]].forEach(p=>{if(!p[1].length)return;m+="\n### "+p[0]+"\n";
   p[1].forEach(x=>{m+="- **"+md(x.author||"بلا اسم")+" ("+md(x.year||"بلا سنة")+")** "+md(x.title)+". "+md(x.jr)+(x.doi?" — doi:"+md(x.doi):"")+"\n  "+(String(x.goal||"").trim()||md(String(x.ab||"").slice(0,240)))+"\n"})})});
 m+="\n## التعليق النقدي والفجوة البحثية\n(يُكتب هنا)\n";return m}
function bibBody(){if(!S.refs.length)return "<p class=\"hint\">لا مراجع بعد.</p>";
 return "<h3>المراجع (APA 7)</h3><table><tr><th>#</th><th>التوثيق</th></tr>"+S.refs.map((r,i)=>"<tr><td>"+(i+1)+"</td><td>"+esc(r.cite)+"</td></tr>").join("")+"</table>"}
function bibMd(){if(!S.refs.length)return"\n## المراجع\n(لا مراجع)\n";return "\n## المراجع (APA 7)\n"+S.refs.map((r,i)=>(i+1)+". "+md(r.cite)).join("\n")+"\n"}
function skelBody(){let h="<h3>بيانات الدراسة</h3><table><tr><th>العنوان</th><td>"+esc(S.p.title)+"</td></tr><tr><th>القطاع</th><td>"+esc(S.p.sector)+"</td></tr><tr><th>المتغيرات</th><td>مستقل: "+esc(S.p.iv)+" / تابع: "+esc(S.p.dv)+(S.p.med?" / وسيط: "+esc(S.p.med):"")+"</td></tr></table><h3>الهيكل العام والأقسام</h3>";
 CH.forEach((c,i)=>{h+="<h4>"+esc(c[0])+"</h4><table><tr><th>القسم</th><th>الحالة</th><th>ملاحظات</th></tr>"+c[1].map((s,j)=>{const o=S.sec[i+"-"+j]||{};return "<tr><td>"+esc(s)+"</td><td>"+(ST[num(o.st)]||ST[0])+"</td><td>"+esc(o.note)+"</td></tr>"}).join("")+"</table>"});
 h+="<h3>الفصل الثاني: الدراسات السابقة والإطار النظري (تجميع آلي)</h3>"+litBody();
 if(S.mx.length)h+="<h3>مصفوفة الاتساق</h3>"+mxBody(S.mx);
 h+=bibBody();return h}
function skelMd(){let m="# هيكل الرسالة: "+(S.p.title||P().name)+"\n\n- القطاع: "+md(S.p.sector)+"\n- المتغير المستقل: "+md(S.p.iv)+"\n- المتغير التابع: "+md(S.p.dv)+(S.p.med?"\n- المتغير الوسيط: "+md(S.p.med):"")+"\n\n## الأقسام\n";
 CH.forEach((c,i)=>{m+="\n### "+md(c[0])+"\n";c[1].forEach((s,j)=>{const o=S.sec[i+"-"+j]||{};m+="- ["+(o.st===2?"x":" ")+"] "+md(s)+(o.note?" — "+md(o.note):"")+"\n"})});
 m+="\n## الدراسات السابقة (تجميع آلي)\n"+litMdBody();
 if(S.mx.length){m+="\n## مصفوفة الاتساق\n";S.mx.forEach(x=>{m+="- "+(x.qt==="d"?"وصفي":"اختباري")+" | "+md(x.q)+" → هدف: "+md(x.obj||"-")+(x.hyp?" | فرض: "+md(x.hyp):"")+"\n"})}
 m+="\n## المراجع (APA 7)\n"+S.refs.map((r,i)=>(i+1)+". "+md(r.cite)).join("\n")+"\n";return m}
function apiRead(){const g=id=>document.getElementById(id);const b=g("apib"),mm=g("apim");
 if(b)apiCfg.base=(b.value.trim()||"http://localhost:11434").replace(/\/+$/,"");if(mm)apiCfg.model=mm.value.trim()||apiCfg.model;saveApi()}
function olmHelp(e){const m=String((e&&e.message)||e||"");
 if(e&&e.name==="AbortError")return "انتهت المهلة: النموذج المحلي بطيء على هذا الجهاز. جرّب نموذجاً أصغر (مثل qwen2.5:1.5b) أو قلّل طول الطلب.";
 if(/404/.test(m))return "النموذج «"+apiCfg.model+"» غير مثبّت. ثبّته بالأمر: ollama pull "+apiCfg.model;
 if((e&&e.name==="TypeError")||/Failed to fetch|fetch failed|NetworkError|Load failed/i.test(m)){
  if(/Android|iPhone|iPad|Mobile/i.test(navigator.userAgent||""))return "الذكاء المحلي (Ollama) يعمل على الحاسوب لا على الهاتف، لذلك لا يتوفر من هنا. بقية الوظائف (تحليل العنوان، مسار الرسالة، البحث، المراجع، تصدير Word) تعمل على الهاتف. لتجربة الذكاء استخدم الحاسوب.";
  return "تعذّر الاتصال بـ Ollama على "+apiCfg.base+". تأكد أن Ollama يعمل، وأنك شغّلت التطبيق عبر «تشغيل المساعد» (أو ضبطت OLLAMA_ORIGINS=*).";}
 return m}
async function llmTest(){apiRead();const w=document.getElementById("olmst");if(w)w.textContent="⏳ جارٍ الاتصال بـ Ollama…";
 try{const j=await jget(apiCfg.base+"/api/tags",6000);OLM.models=((j&&j.models)||[]).map(x=>x.name).filter(Boolean);OLM.ok=true;
  const has=OLM.models.some(n=>n===apiCfg.model||n.split(":")[0]===apiCfg.model);
  const msg=OLM.models.length?("✅ متصل. النماذج المثبّتة: "+OLM.models.join("، ")+(has?"":" — ⚠ النموذج المحدد غير مثبّت: ollama pull "+apiCfg.model)):"✅ متصل لكن لا توجد نماذج مثبّتة. نفّذ: ollama pull "+apiCfg.model;
  if(w)w.textContent=msg;toast(has?"Ollama جاهز":"Ollama يعمل لكن النموذج غير مثبّت",!has)}
 catch(e){OLM.ok=false;const m=olmHelp(e);if(w)w.textContent="❌ "+m;toast("تعذّر الاتصال بـ Ollama",1)}}
async function llmGo(){apiRead();
 const ta=document.getElementById("elpr"),prompt=(ta&&ta.value.trim())||"";
 if(!prompt){toast("اكتب «طلب التوليد» أو اختر قالباً",1);return}
 const out=document.getElementById("elout");if(out)out.innerHTML='<p class="hint">⏳ جارٍ التوليد محلياً على جهازك… قد يستغرق عدة دقائق حسب سرعة الجهاز.</p>';
 const ctx=("الدراسة: "+(S.p.title||"")+" | المستقل: "+S.p.iv+" / التابع: "+S.p.dv+(S.p.med?" / وسيط: "+S.p.med:"")).slice(0,2500)+"\n\n"+litMdBody().slice(0,3500);
 try{const r=await (async()=>{const c=new AbortController(),tm=setTimeout(()=>c.abort(),600000);
   try{const rr=await fetch(apiCfg.base+"/api/chat",{method:"POST",signal:c.signal,headers:{"Content-Type":"application/json"},
     body:JSON.stringify({model:apiCfg.model,stream:false,options:{temperature:0.3,num_ctx:4096},messages:[
       {role:"system",content:"أنت مساعد أكاديمي عربي لكتابة رسالة دكتوراه. اكتب نصاً علمياً منظماً. لا تختلق مراجع أو أرقاماً أو اقتباسات أو نتائج؛ استخدم فقط ما في السياق، وإن نقصت البيانات فاذكر ذلك بوضوح ليراجعه الباحث."},
       {role:"user",content:prompt+"\n\n--- سياق من مشروع الباحث ---\n"+ctx}]})});
    if(!rr.ok){throw new Error("HTTP "+rr.status)}
    const j=await rr.json();return (j&&j.message&&j.message.content)?j.message.content:"";
   }finally{clearTimeout(tm)}})();
  if(!r.trim())throw new Error("أعاد النموذج ردّاً فارغاً — جرّب صياغة أخرى أو نموذجاً آخر");
  if(out)out.textContent=r;
  save();toast("اكتمل التوليد — راجع النص وحرّره قبل الاستخدام")}
 catch(e){const m=olmHelp(e);if(out)out.innerHTML='<div class="rule" style="border-top:0"><span class="badge fl">خطأ</span><div>'+esc(m)+'</div></div>';toast("تعذّر التوليد",1)}}
function llmSave(){const out=document.getElementById("elout"),txt=(out&&(out.innerText||out.textContent))||"";
 if(!txt.trim()){toast("لا يوجد ناتج لحفظه",1);return}
 dl("academic-draft.md","\ufeff# مسودة مولّدة — "+P().name+"\n\n"+md(S.p.title)+"\n\n"+txt+"\n","text/markdown;charset=utf-8");toast("حُفظت المسودة (Markdown)")}
function elq1(){return "اكتب مسودة «مقدمة الفصل الثاني: الإطار النظري والدراسات السابقة» للدراسة. ابدأ بمقدمة تمهيدية، ثم عرّف المتغير المستقل «"+(S.p.iv||"")+"» والمتغير التابع «"+(S.p.dv||"")+"»، ثم امهد للدراسات السابقة بعناوين فرعية مرقّمة."}
function elq2(){return "اكتب «تعليقاً نقدياً» على الدراسات السابقة الواردة في السياق: نقاط الاتفاق، نقاط الاختلاف (المجتمع/العينة/المنهج/النتائج)، ثم الفجوة البحثية التي تسوّغ الدراسة الحالية. اعتمد فقط على الدراسات المذكورة في السياق ولا تختلق غيرها."}
function elq3(){return "اقترح «محاور وأسئلة الاستبيان الأولية» مرتبطة بمتغيرات الدراسة: المستقل «"+(S.p.iv||"")+"»، التابع «"+(S.p.dv||"")+(S.p.med?"»، الوسيط «"+S.p.med:"")+"». استخدم مقياس ليكرت الخماسي، ورتّب الأسئلة تحت كل محور مع بيان هدف كل محور."}
function vAuto(){
 return `<div class="card"><h2>🤖 المولّد الآلي للمادة العلمية</h2>
 <p class="hint">يأخذ موضوعك ومتغيراتك من «ملف المشروع»، ويبحث آلياً في فهرس <b>OpenAlex</b> العالمي (مجاني بلا مفتاح)، ثم تُعلّم ما يناسبك فيُضاف <b>كدراسات سابقة + مراجع APA</b>، ثم <b>يُفحص كل مرجع آلياً</b> عبر Crossref/OpenAlex للتأكد من صحته وعدم سحبه. بقية أجزاء التطبيق تعمل بلا إنترنت، والإنترنت اختياري للبحث والفحص.</p></div>
 <div class="card"><h3>1) البحث الآلي وجلب الدراسات والمراجع</h3>
 <div class="grid">
  <div><label>كلمات إضافية (اختياري)</label><input id="agx" value="${esc(F.ag)}" placeholder="مثال: digital transformation SMEs"></div>
  <div><label>من سنة</label><input id="agfrom" type="number" inputmode="numeric" value="${esc(S.p.minY)}"></div>
  <div><label>إلى سنة</label><input id="agto" type="number" inputmode="numeric" value="${esc(F.agto)}" placeholder="${new Date().getFullYear()}"></div>
  <div><label>عدد النتائج لكل دفعة</label><input id="agn" type="number" inputmode="numeric" value="${esc(F.agn||"12")}"></div>
 </div>
 <div class="row"><button class="btn" id="aggo">🔍 ابحث واجلب الآن</button>
  <button class="btn sec" id="agall">تحديد الكل</button>
  <span class="hint" id="agwait">سيُبنى الاستعلام تلقائياً من المتغيرات والقطاع والعنوان (يُفضّل إضافة كلمات إنجليزية).</span></div>
 <p class="hint">المحدّد حالياً: <b id="agcnt">0</b> — يُستبعد المسحوب تلقائياً.</p>
 <div id="aglist"></div>
 <div class="row"><button class="btn" id="agadd">➕ أضف المحدّد كدراسات ومراجع (مع الفحص الآلي)</button></div></div>
 <div class="card"><h3>2) مستندات التجميع الجاهزة</h3>
 <p class="hint">تُبنى من الدراسات والمراجع والمصفوفة الموجودة حالياً في مشروعك.</p>
 <div class="row">
  <button class="btn" id="rexpW">📄 تقرير المراجعة الأدبية (Word)</button>
  <button class="btn sec" id="rexpM">📝 تقرير المراجعة (Markdown)</button></div>
 <div class="row">
  <button class="btn" id="skW">📄 هيكل الرسالة الكامل (Word)</button>
  <button class="btn sec" id="skM">📝 هيكل الرسالة (Markdown)</button></div></div>
 <div class="card"><h3>3) مولّد النص الأكاديمي المحلي (Ollama — مجاني بلا مفتاح)</h3>
 <p class="hint">يعمل على جهازك عبر <b>Ollama</b> دون إنترنت ودون أي مفتاح أو اشتراك، ولا يُرسل نصوصك لأي جهة. الجودة والسرعة تعتمدان على ذاكرة جهازك (RAM): النماذج الأصغر أسرع لكنها أضعف، وجودتها في العربية محدودة، لذا اعتبر الناتج مسودة تحتاج مراجعة دقيقة.</p>
 <div class="grid">
  <div><label>عنوان Ollama</label><input id="apib" value="${esc(apiCfg.base)}"></div>
  <div><label>النموذج المحلي</label><input id="apim" list="olmlist" value="${esc(apiCfg.model)}"><datalist id="olmlist">${["qwen2.5:1.5b","qwen2.5:3b","qwen2.5:7b","llama3.2:3b","gemma2:2b"].concat(OLM.models).map(n=>'<option value="'+esc(n)+'">').join("")}</datalist></div>
 </div>
 <div class="row"><button class="btn sec" id="apitest">🔌 اختبر الاتصال بـ Ollama</button><span class="hint" id="olmst">لم يُختبر بعد. النموذج الافتراضي qwen2.5:3b يناسب غالباً جهازاً بذاكرة 8 جيجابايت.</span></div>
 <div class="row">
  <button class="mini" id="elq1">قالب: مقدمة الفصل الثاني</button>
  <button class="mini" id="elq2">تعليق نقدي وفجوة</button>
  <button class="mini" id="elq3">أسئلة استبيان أولية</button></div>
 <label>طلب التوليد</label><textarea id="elpr" placeholder="اكتب ما تريده… أو اختر قالباً أعلاه">${esc(F.elpr)}</textarea>
 <div class="row"><button class="btn" id="elgo">✨ ولّد النص</button>
  <button class="btn sec" id="elsave">💾 حفظ المسودة (MD)</button></div>
 <div id="elout" class="mono" contenteditable="true" style="white-space:pre-wrap;max-height:360px;overflow:auto"></div>
 <div class="card" style="background:var(--acc2)"><b>تنبيه أخلاقي</b><p class="hint" style="margin:6px 0 0">الناتج مسودة أولية للمساعدة لا أكثر؛ راجعها وحرّرها ووثّق استخدامك وفق سياسة جامعتك.</p></div></div>`}
function agallAct(){AG.forEach(o=>{if(!o.is_retracted)AGS[o.doi]=1});const el=document.getElementById("aglist");if(el)el.innerHTML=agHtml();agcnt()}
function agoneAct(i){const o=AG[i];if(!o)return;if(AGS[o.doi])delete AGS[o.doi];else AGS[o.doi]=1;const el=document.getElementById("aglist");if(el)el.innerHTML=agHtml();agcnt()}
function elqAct(fn){const e=document.getElementById("elpr");if(e){e.value=fn();F.elpr=e.value}}

/* ===== شاشة البداية: عنوان واحد ← تحليل ← بحث عن دراسات حقيقية ===== */
/* قاعدة صغيرة لمفاهيم شائعة لها إطار تأسيسي معروف؛ الأبعاد قد تختلف ترجمتها بين الدراسات فتحقق من المصدر الأصلي */
const KB=[
 {ar:["القيادة التحويلية"],en:"transformational leadership",dims:["التأثير المثالي","الدافعية الإلهامية","الاستثارة الفكرية","الاعتبارية الفردية"],src:"Bass (1985)؛ Bass & Avolio — مقياس MLQ"},
 {ar:["الالتزام التنظيمي"],en:"organizational commitment",dims:["الالتزام العاطفي","الالتزام المستمر","الالتزام المعياري"],src:"Allen & Meyer (1990)"},
 {ar:["التمكين النفسي"],en:"psychological empowerment",dims:["المعنى","الكفاءة","تقرير المصير","التأثير"],src:"Spreitzer (1995)"},
 {ar:["المواطنة التنظيمية"],en:"organizational citizenship behavior",dims:["الإيثار","الضمير الحي","الروح الرياضية","اللباقة","السلوك الحضاري"],src:"Organ (1988)"},
 {ar:["الاحتراق الوظيفي","الإنهاك الوظيفي","الاحتراق النفسي"],en:"burnout",dims:["الإجهاد الانفعالي","تبلد المشاعر","نقص الإنجاز الشخصي"],src:"Maslach & Jackson (1981)"},
 {ar:["الانخراط الوظيفي","الاستغراق الوظيفي","الارتباط الوظيفي"],en:"work engagement",dims:["الحيوية","التفاني","الاستغراق"],src:"Schaufeli et al. (2002)"},
 {ar:["الأداء الوظيفي","أداء العاملين","أداء الموظفين"],en:"job performance",dims:["الأداء المهمّي (Task)","الأداء السياقي (Contextual)"],src:"Borman & Motowidlo (1993)"}];
const nz=s=>String(s||"").toLowerCase().replace(/[\u064B-\u0652\u0640]/g,"").replace(/[أإآ]/g,"ا").replace(/ى/g,"ي").replace(/ة/g,"ه").replace(/\s+/g," ").trim();
function kbFind(txt){const n=nz(txt);if(!n)return null;return KB.find(k=>k.ar.some(a=>n.includes(nz(a)))||n.includes(k.en))||null}
const cv=s=>String(s||"").replace(/^[\s:،,.\-–—]+|[\s:،,.\-–—]+$/g,"").replace(/\s+/g," ").trim();
function fixLam(s){s=String(s||"").trim();if(s.startsWith("لل"))return "ال"+s.slice(2);if(s.startsWith("لـ"))return s.slice(2);if(s.startsWith("ل")&&s.length>3)return s.slice(1);return s}
const ORG="(?:قطاع|شركة|شركات|الشركة|الشركات|مؤسسة|مؤسسات|المؤسسات|بنك|بنوك|البنوك|مصرف|مصارف|وزارة|وزارات|هيئة|جامعة|جامعات|الجامعات|مستشفى|مستشفيات|المستشفيات|المنظمات|منظمات|مصانع|المصانع|فنادق|الفنادق)";
const SETAR=new RegExp("(?:^|\\s)(?:دراسة\\s+\\S+\\s+)?(?:على|في|لدى)\\s+("+ORG+"(?:\\s.*)?)$");
const MEDAR=/(?:^|\s)(?:الدور\s+)?(الوسيط|المعد[\u064B-\u0652]*ل)\s+(.+)$/;
function parseTitle(t){
 t=String(t||"").replace(/\s+/g," ").trim();
 const r={iv:"",dv:"",med:"",medType:"",setting:"",pop:"",design:"",ok:false};if(!t)return r;
 let main=t,sub="",m;
 if((m=t.match(/^(.+?)\s*(?::|：|\s[–—-]\s)\s*(.+)$/))){main=m[1].trim();sub=m[2].trim()}
 const latin=/[A-Za-z]/.test(t)&&!hasAr(t);
 /* الجزء بعد النقطتين: جهة/وسيط */
 if(sub){let rest=sub;
  if(latin){if((m=rest.match(/^(.*?)\s+(?:in|at|among)\s+(.+)$/i))){r.setting=cv(m[2]);rest=m[1]}
   else if((m=rest.match(/^(?:evidence from|a (?:field |case )?study (?:of|on|in)|case of)\s+(.+)$/i))){r.setting=cv(m[1]);rest=""}
   if((m=rest.match(/(mediating|moderating)\s+(?:role|effect)\s+of\s+(.+)$/i))){r.med=cv(m[2]);r.medType=/moder/i.test(m[1])?"معدّل":"وسيط";rest=""}}
  else{if((m=rest.match(SETAR))){r.setting=cv(m[1]);rest=rest.slice(0,m.index).trim()}
   if((m=rest.match(MEDAR))){r.med=cv(fixLam(m[2]));r.medType=m[1]==="الوسيط"?"وسيط":"معدّل";rest=rest.slice(0,m.index).trim()}
   else if(rest&&!r.setting&&!/^دراسة\s+\S+$/.test(rest)){r.setting=cv(rest.replace(/^دراسة\s+\S+\s*(?:على|في|لدى)?\s*/,""));rest=""}}}
 else if(latin){if((m=main.match(/^(.*\bon\b.*?)\s+in\s+(.+)$/i))){r.setting=cv(m[2]);main=m[1]}}
 else if((m=main.match(SETAR))){r.setting=cv(m[1]);main=main.slice(0,m.index).trim()}
 /* المتغيرات من الصيغة الرئيسية */
 if((m=main.match(/^الدور\s+(?:الوسيط|المعد[\u064B-\u0652]*ل)\s+(.+?)\s+في\s+(?:العلاقة|العلاقه)\s+بين\s+(.+?)\s+و(\S.*)$/))){r.med=cv(fixLam(m[1]));r.medType=r.medType||"وسيط";r.iv=cv(m[2]);r.dv=cv(m[3]);r.design="relation"}
 else if((m=main.match(/^(?:أثر|اثر|تأثير|تاثير|انعكاس)\s+(.+?)\s+(?:على|علي|في)\s+(.+)$/))){r.iv=cv(m[1]);r.dv=cv(m[2]);r.design="effect"}
 else if((m=main.match(/^(?:دور|إسهام|مساهمة)\s+(.+?)\s+في\s+(.+)$/))){r.iv=cv(m[1]);r.dv=cv(m[2]);r.design="role"}
 else if((m=main.match(/^(?:العلاقة|العلاقه|الارتباط|علاقة|ارتباط)\s+بين\s+(.+?)\s+و(\S.*)$/))){r.iv=cv(m[1]);r.dv=cv(m[2]);r.design="relation"}
 else if((m=main.match(/^(?:the\s+)?(?:impact|effect|influence)\s+of\s+(.+?)\s+on\s+(.+)$/i))){r.iv=cv(m[1]);r.dv=cv(m[2]);r.design="effect"}
 else if((m=main.match(/^(?:the\s+)?role\s+of\s+(.+?)\s+in\s+(.+)$/i))){r.iv=cv(m[1]);r.dv=cv(m[2]);r.design="role"}
 else if((m=main.match(/^(?:the\s+)?relationship\s+between\s+(.+?)\s+and\s+(.+)$/i))){r.iv=cv(m[1]);r.dv=cv(m[2]);r.design="relation"}
 /* جمهور داخل المتغير التابع (لدى العاملين...) */
 if(r.dv&&(m=r.dv.match(/^(.+?)\s+لدى\s+(.+)$/))){r.dv=cv(m[1]);r.pop=cv(m[2]);if(!r.setting)r.setting=r.pop}
 r.ok=!!(r.iv&&r.dv);return r}
function qaTitle(p,pr){const out=[],t=String(p.title||"").trim(),w=t.split(/\s+/).filter(Boolean).length;
 const add=(l,x)=>out.push({l:l,t:x});
 if(w<6)add("wr","العنوان قصير ("+w+" كلمات): غالباً لا يكفي لتحديد المتغيرات والجهة معاً.");
 else if(w>25)add("wr","العنوان طويل ("+w+" كلمة): الأفضل ألا يتجاوز نحو 20–25 كلمة مع إبقاء المتغيرات والسياق.");
 else add("ok","طول العنوان مناسب ("+w+" كلمة).");
 if(!pr.ok)add("wr","لم أتعرّف تلقائياً على المتغيرات. جرّب صيغة «أثر X على Y» أو «العلاقة بين X وY» أو «دور X في Y»، أو اكتب المتغيرات يدوياً في الحقول أدناه.");
 else add("ok","تم تمييز متغير مستقل ومتغير تابع؛ راجعهما أدناه فالاستخراج آلي وقد يخطئ.");
 if(pr.design==="effect")add("wr","كلمة «أثر/تأثير» تتضمن ادعاءً سببياً. إن كان تصميمك استبياناً مقطعياً (في وقت واحد) فالأسلم «العلاقة» أو «دور»، أو ابقَ على «أثر» مع تبرير نظري وأسلوب تحليل مناسب (انحدار/نمذجة معادلات) والإقرار بحدود الاستدلال السببي.");
 const set=String(p.sector||"").trim();
 if(!set)add("wr","لا توجد جهة أو قطاع محدد. رسالة DBA تُبنى عادةً على مشكلة مهنية في سياق محدد؛ اذكر القطاع أو المؤسسة في الحقل أدناه.");
 else if(set.split(/\s+/).length<2)add("wr","وصف الجهة «"+set+"» عام جداً؛ حدّد القطاع والموقع أو نوع المؤسسة.");
 else add("ok","السياق (الجهة/القطاع) محدد.");
 if(pr.dv&&/\s(?:و|and)\s*\S/.test(" "+pr.dv)&&pr.design!=="relation")add("wr","المتغير التابع «"+pr.dv+"» قد يضم أكثر من متغير؛ إن كان كذلك ففكّر في فصلهما أو تعريفهما كأبعاد لمتغير واحد.");
 if(p.iv&&!kbFind(p.iv)&&!kbFind(p.dv)&&!kbFind(p.med))add("wr","لا أملك في قاعدتي المدمجة أبعاداً جاهزة لمتغيراتك؛ ستحتاج لاستخراجها من الدراسات الحقيقية التي سيجلبها البحث أدناه.");
 return out}
function sugTitles(p,pr){const iv=p.iv||pr.iv,dv=p.dv||pr.dv,med=p.med||pr.med,set=p.sector||pr.setting||"[حدّد الجهة أو القطاع]";const o=[];
 if(!iv||!dv)return o;
 o.push({t:"العلاقة بين "+iv+" و"+dv+" لدى العاملين في "+set,why:"صيغة «العلاقة» أسلم منهجياً مع الاستبيان المقطعي لأنها لا تدّعي سببية. اختر هذه إن لم يكن لديك تصميم يدعم الاستدلال السببي."});
 o.push({t:"أثر "+iv+" على "+dv+": دراسة ميدانية على "+set,why:"تُبقي فرضية الأثر وتضيف الجهة صراحة. تحتاج دعماً من نموذج نظري وأسلوب تحليل مناسب."});
 if(med)o.push({t:"الدور "+(p.medType==="معدّل"?"المعدّل":"الوسيط")+" لـ"+med+" في العلاقة بين "+iv+" و"+dv+": دراسة تطبيقية على "+set,why:"يبرز المتغير الذي ذكرته ويوضح آلية العلاقة؛ يتطلب أن تدعمه الأدبيات."});
 else o.push({t:"الدور الوسيط لـ[متغير مقترح] في العلاقة بين "+iv+" و"+dv+": دراسة تطبيقية على "+set,why:"إضافة وسيط تقوّي الإسهام النظري لكن لا تُضاف إلا إن دعمتها الدراسات السابقة؛ استبدل [متغير مقترح] بعد مراجعة الأدبيات."});
 o.push({t:(p.title||"").split(/[:：]/)[0].trim()+": نحو إطار عملي مقترح لتحسين "+dv+" في "+set,why:"رسائل DBA يُنتظر منها إسهام مهني تطبيقي؛ هذه الصيغة تُظهره. تأكد أن الجامعة تقبل عنواناً بهذا الشكل."});
 return o}
function hmEn(){return [p0("iv"),p0("dv"),p0("med")].map(x=>kbFind(x)).filter(Boolean).map(k=>k.en).filter((x,i,a)=>a.indexOf(x)===i).join(" ")}
function p0(k){return (S.p&&S.p[k])||""}
function hmAnalyze(){const t=String(S.p.title||"").trim();if(!t){toast("اكتب عنوان الرسالة أولاً",1);return}
 const pr=parseTitle(t),fresh=S.hmT!==t;
 ["iv","dv","med"].forEach(k=>{if(pr[k]&&(fresh||!S.p[k]))S.p[k]=pr[k]});
 if(pr.setting&&(fresh||!S.p.sector))S.p.sector=pr.setting;
 if(pr.medType)S.p.medType=pr.medType;
 S.hmT=t;save();render();toast(pr.ok?"تم التحليل — راجع ما استُخرج وصحّحه":"لم أميّز المتغيرات تلقائياً — أدخلها يدوياً",!pr.ok)}
async function olmChat(messages,ms){const c=new AbortController(),tm=setTimeout(()=>c.abort(),ms||600000);
 try{const rr=await fetch(apiCfg.base+"/api/chat",{method:"POST",signal:c.signal,headers:{"Content-Type":"application/json"},body:JSON.stringify({model:apiCfg.model,stream:false,options:{temperature:0.2,num_ctx:4096},messages:messages})});
  if(!rr.ok)throw new Error("HTTP "+rr.status);const j=await rr.json();return (j&&j.message&&j.message.content)||""}finally{clearTimeout(tm)}}
async function hmGap(){
 const st=S.studies.filter(s=>s.title);
 if(st.length<3){toast("أضف 3 دراسات على الأقل (ابحث وأضف أولاً) ليُبنى التحليل على مصادر حقيقية",1);return}
 const out=document.getElementById("hmout");if(out)out.innerHTML='<p class="hint">⏳ جارٍ التحليل محلياً… قد يستغرق عدة دقائق.</p>';
 const list=st.slice(0,12);
 const ctx=list.map((s,i)=>"["+(i+1)+"] "+(s.author||"مؤلف غير مذكور")+" ("+(s.year||"؟")+") — "+s.title+(s.ab?"\nمستخلص: "+String(s.ab).slice(0,450):"")).join("\n\n").slice(0,5500);
 const sys="أنت مساعد بحثي أكاديمي. استخدم فقط الدراسات المرقّمة المرفقة. لا تذكر أي دراسة أو رقم أو نتيجة غير موجودة فيها. أشِر لكل نقطة برقم الدراسة الداعمة مثل [2]. إن لم تكفِ المعلومات فقل ذلك صراحة.";
 const usr="عنوان الرسالة: "+(S.p.title||"")+"\nالمستقل: "+(S.p.iv||"")+" | التابع: "+(S.p.dv||"")+(S.p.med?" | الوسيط: "+S.p.med:"")+(S.p.sector?" | السياق: "+S.p.sector:"")+"\n\nالدراسات:\n"+ctx+"\n\nالمطلوب بالعربية وباختصار: (1) ما تتفق عليه هذه الدراسات. (2) ما لا تغطيه (السياق/القطاع/البلد/المنهج/المتغيرات). (3) ثلاث فجوات محتملة بوصفها فرضيات تحتاج تحققاً، مع رقم الدراسة الداعمة لكل واحدة.";
 try{let r=await olmChat([{role:"system",content:sys},{role:"user",content:usr}]);
  if(!r.trim())throw new Error("أعاد النموذج ردّاً فارغاً");
  const bad=[];(r.match(/\[(\d+)\]/g)||[]).forEach(x=>{const n=+x.slice(1,-1);if(n<1||n>list.length)bad.push(x)});
  if(bad.length)r+="\n\n⚠ تنبيه آلي: النص يشير إلى أرقام دراسات غير موجودة ("+bad.filter((x,i,a)=>a.indexOf(x)===i).join("، ")+") — تجاهل تلك النقاط.";
  S.gapNote=r;S.gapN=list.length;save();if(out)out.textContent=r;toast("اكتمل — هذه فرضيات أولية تحتاج تحققك")}
 catch(e){const m=olmHelp(e);if(out)out.innerHTML='<div class="rule" style="border-top:0"><span class="badge fl">خطأ</span><div>'+esc(m)+'</div></div>';toast("تعذّر التحليل",1)}}
function vHome(){
 const t=String(S.p.title||"").trim(),pr=parseTitle(t),dims=[S.p.iv,S.p.dv,S.p.med].map(x=>({x:x,k:kbFind(x)})).filter(o=>o.x&&o.k);
 let h='<div class="card"><h2>🎓 ابدأ بعنوان رسالتك</h2><p class="hint">اكتب عنوانك المبدئي فقط. سأحلله، وأستخرج المتغيرات، وأقترح صياغات أفضل مع المبررات، ثم أبحث لك عن دراسات حقيقية بروابطها. العنوان نقطة بداية؛ جودة الرسالة تحتاج مصادر موثوقة وبيانات ميدانية حقيقية ومتطلبات جامعتك.</p>'+
 '<label for="hmt">عنوان الرسالة</label><textarea id="hmt" rows="2" data-l="p" data-k="title" placeholder="مثال: أثر القيادة التحويلية على الأداء الوظيفي: دراسة ميدانية على شركات الاتصالات">'+esc(S.p.title)+'</textarea>'+
 '<div class="row"><button class="btn" id="hmgo">🔎 حلّل العنوان</button></div></div>';
 if(!t)return h;
 h+='<div class="card"><h3>ما فهمته من العنوان (صحّحه إن أخطأت)</h3><div class="grid">'+
  '<div><label>المتغير المستقل</label><input data-l="p" data-k="iv" value="'+esc(S.p.iv)+'"></div>'+
  '<div><label>المتغير التابع</label><input data-l="p" data-k="dv" value="'+esc(S.p.dv)+'"></div>'+
  '<div><label>المتغير الوسيط/المعدّل (إن وجد)</label><input data-l="p" data-k="med" value="'+esc(S.p.med)+'"></div>'+
  '<div><label>الجهة / القطاع</label><input data-l="p" data-k="sector" value="'+esc(S.p.sector)+'"></div></div>'+
  '<p class="hint">يُحفظ ما تكتبه هنا تلقائياً في «ملف المشروع».</p></div>';
 h+='<div class="card"><h3>ملاحظات أكاديمية على العنوان</h3>'+qaTitle(S.p,pr).map(o=>'<div class="rule" style="border-top:0"><span class="badge '+o.l+'">'+LBL[o.l]+'</span><div>'+esc(o.t)+'</div></div>').join("")+'</div>';
 const sg=sugTitles(S.p,pr);
 if(sg.length)h+='<div class="card"><h3>صياغات مقترحة مع المبررات</h3><p class="hint">اختر ما يناسبك أو عدّله. الأقواس [ ] تعني أن عليك استبدال المحتوى بعد مراجعة الأدبيات.</p>'+sg.map((o,i)=>'<div class="rule"><div style="flex:1"><b>'+esc(o.t)+'</b><small>'+esc(o.why)+'</small></div><div class="row"><button class="mini" data-hmadopt="'+i+'">اعتمد هذا العنوان</button></div></div>').join("")+'</div>';
 if(dims.length)h+='<div class="card"><h3>أبعاد شائعة في الأدبيات لمتغيراتك</h3><p class="hint">من أطر تأسيسية معروفة. تختلف ترجمات الأبعاد وتصنيفاتها بين الدراسات، فتحقق من المصدر الأصلي ومن توافقها مع الأداة التي ستعتمدها قبل اعتمادها.</p>'+dims.map(o=>'<div class="rule" style="border-top:0"><div><b>'+esc(o.x)+'</b><small>'+esc(o.k.dims.join(" · "))+'</small><small>المصدر التأسيسي للتحقق منه: '+esc(o.k.src)+'</small></div></div>').join("")+'</div>';
 h+='<div class="card"><h3>الخطوة التالية: دراسات حقيقية بروابطها</h3><p class="hint">يبحث في فهرس OpenAlex المجاني (يحتاج إنترنت) ويستبعد الأبحاث المسحوبة. نتائج البحث بالإنجليزية أوفر وأدق، فاكتب كلمات إنجليزية للمتغيرات.</p>'+
  '<label>كلمات البحث الإنجليزية</label><input id="agx" value="'+esc(F.ag||hmEn())+'" placeholder="مثال: transformational leadership job performance">'+
  '<div class="row"><button class="btn" id="hmsearch">🔍 ابحث عن الدراسات</button><button class="btn sec" id="hmgap">🧭 اقترح الفجوة البحثية (نموذج محلي)</button></div>'+
  '<p class="hint">تحليل الفجوة يعتمد فقط على الدراسات التي أضفتها (3 على الأقل)، ويتطلب تشغيل Ollama. ناتجه فرضية تحتاج تحققك وليس حكماً نهائياً.</p>'+
  '<div id="hmout" class="mono" contenteditable="true" style="white-space:pre-wrap;max-height:380px;overflow:auto">'+esc(S.gapNote||"")+'</div></div>';
 h+='<div class="card" style="background:var(--acc2)"><h3>ما ينقص رسالتك ولا يمكن استنتاجه من العنوان</h3><div class="rule" style="border-top:0"><span class="badge fl">مطلوب منك</span><div>• متطلبات جامعتك (دليل الرسائل: عدد الفصول والكلمات ونمط التوثيق).<br>• موافقة المشرف على العنوان والمشكلة.<br>• سياق المؤسسة ومن يملك الإذن بالوصول للبيانات والعاملين.<br>• بيانات ميدانية حقيقية — لا يُختلق أي رقم أو نتيجة أو مرجع.</div></div></div>';
 return h}

/* ===== المرحلة 3: مسار الرسالة + التحقق من الاتساق + استيراد الملفات + تصدير docx ===== */
const PF=[["prob","مشكلة الدراسة"],["obj","أهداف الدراسة"],["q","أسئلة الدراسة"],["hyp","فرضيات الدراسة"],["theory","الإطار النظري / النظرية الحاكمة"],["method","منهج وتصميم الدراسة"],["pop","مجتمع الدراسة"],["sample","العينة وحجمها"],["instr","أداة جمع البيانات"],["stats","أساليب التحليل الإحصائي"],["res","النتائج (تُكتب بعد جمع البيانات الحقيقية فقط)"],["rec","التوصيات (تُكتب بعد النتائج فقط)"]];
const PD=()=>{S.path=S.path||{};return S.path};
const lns=s=>String(s||"").split(/\n+/).map(x=>x.trim()).filter(Boolean);
function sampleSize(N,e,z,p){e=e||0.05;z=z||1.96;p=p||0.5;const n0=z*z*p*(1-p)/(e*e);N=num(N);return N>0?Math.ceil(n0/(1+(n0-1)/N)):Math.ceil(n0)}
function genPath(){const pr=parseTitle(S.p.title),iv=S.p.iv||pr.iv||"[المتغير المستقل]",dv=S.p.dv||pr.dv||"[المتغير التابع]",med=S.p.med||pr.med||"",set=S.p.sector||pr.setting||"[الجهة/القطاع]",ds=pr.design||"effect";
 const kiv=kbFind(iv),dims=kiv?kiv.dims:[];
 const rel=ds==="relation"?"العلاقة بين "+iv+" و"+dv:ds==="role"?"دور "+iv+" في "+dv:"أثر "+iv+" على "+dv;
 const o={};
 o.prob="[اذكر هنا الظاهرة المهنية الملاحظة في "+set+" مع مؤشر أو مصدر موثق (تقرير داخلي، إحصاءات، دراسة استطلاعية)]. وفي ضوء ذلك تتحدد مشكلة الدراسة في السؤال الرئيس: ما "+rel+" في "+set+"؟";
 o.q="1) ما مستوى "+iv+" في "+set+"؟\n2) ما مستوى "+dv+" في "+set+"؟\n3) ما "+rel+"؟"+dims.map((d,i)=>"\n"+(4+i)+") ما "+(ds==="relation"?"علاقة":"أثر")+" بُعد «"+d+"» "+(ds==="relation"?"بـ":"على ")+dv+"؟").join("")+(med?"\n"+(4+dims.length)+") هل يتوسط «"+med+"» العلاقة بين "+iv+" و"+dv+"؟":"");
 o.obj="1) قياس مستوى "+iv+" في "+set+".\n2) قياس مستوى "+dv+" في "+set+".\n3) تحديد "+rel+"."+dims.map((d,i)=>"\n"+(4+i)+") تحديد "+(ds==="relation"?"علاقة":"أثر")+" بُعد «"+d+"» "+(ds==="relation"?"بـ":"على ")+dv+".").join("")+(med?"\n"+(4+dims.length)+") اختبار الدور الوسيط لـ«"+med+"».":"")+"\n"+(4+dims.length+(med?1:0))+") تقديم توصيات تطبيقية مستندة إلى النتائج الفعلية (بعد تحليل البيانات).";
 const H=ds==="relation"?"توجد علاقة ارتباط ذات دلالة إحصائية عند مستوى 0.05 بين ":"يوجد أثر ذو دلالة إحصائية عند مستوى 0.05 ";
 o.hyp="H1: "+(ds==="relation"?H+iv+" و"+dv+".":H+"لـ"+iv+" على "+dv+".")+dims.map((d,i)=>"\nH1."+(i+1)+": "+(ds==="relation"?"توجد علاقة ذات دلالة إحصائية بين بُعد «"+d+"» و"+dv+".":"يوجد أثر ذو دلالة إحصائية لبُعد «"+d+"» على "+dv+".")).join("")+(med?"\nH2: يتوسط «"+med+"» العلاقة بين "+iv+" و"+dv+" بدلالة إحصائية.":"")+"\n[الاتجاه (موجب/سالب) يُحدَّد من الدراسات السابقة وليس من التخمين؛ عدّل الصياغة بعد مراجعتها.]";
 o.theory="[حدّد النظرية الحاكمة من الدراسات السابقة التي جمعتها في تبويب «الدراسات السابقة»، واذكر مرجعها الأصلي.]";
 o.method="المنهج الكمي (الوصفي التحليلي) بتصميم مقطعي يعتمد الاستبيان، لاختبار الفرضيات أعلاه. [إن اشترطت جامعتك منهجاً مختلطاً فأضف مرحلة استكشافية بالمقابلات.]";
 o.pop="جميع العاملين في "+set+" [اذكر العدد الإجمالي والفئات الوظيفية من سجلات المؤسسة].";
 const N=num(PD().N);o.sample=N>0?"بلغ حجم المجتمع "+N+" فرداً؛ وبحساب حجم العينة بمعادلة كوكران مع التصحيح للمجتمع المحدود (ثقة 95%، هامش خطأ 5%) يكون الحد الأدنى "+sampleSize(N)+" مشاركاً، [ويُزاد لتعويض الاستبيانات غير الصالحة]. [حدّد أسلوب السحب: عشوائي طبقي/بسيط/ميسّر مع التبرير.]":"[أدخل حجم المجتمع في الحاسبة أعلاه ليُحسب الحد الأدنى للعينة.]";
 o.instr="استبيان من أقسام: (1) البيانات الديموغرافية، (2) مقياس "+iv+(dims.length?" (أبعاده الشائعة: "+dims.join("، ")+" — يُتحقق منها من المصدر)":"")+"، (3) مقياس "+dv+(med?"، (4) مقياس "+med:"")+". بمقياس ليكرت الخماسي. [استخدم مقاييس منشورة ومحكّمة مع توثيق مصدرها وإذن استخدامها إن لزم، وأجرِ تحكيماً واختباراً تجريبياً للصدق والثبات؛ لا تؤلّف المقاييس من الصفر دون ذلك.]";
 o.stats="اختبار الثبات (ألفا كرونباخ)، والصدق (تحليل عاملي استكشافي/توكيدي)، والإحصاء الوصفي، واختبار افتراضات الانحدار (التوزيع الطبيعي والارتباط الخطي المتعدد)، والارتباط، والانحدار البسيط/المتعدد"+(med?"، وتحليل الوساطة (Bootstrap أو نمذجة المعادلات البنائية)":"")+". البرمجيات المجانية المناسبة: JASP أو jamovi أو R (بينما SPSS وAMOS مدفوعان).";
 return o}
function pathFill(){const d=genPath(),P_=PD();let n=0;["prob","obj","q","hyp","theory","method","pop","sample","instr","stats"].forEach(k=>{if(!String(P_[k]||"").trim()){P_[k]=d[k];n++}});
 save();render();toast(n?"أُنشئت مسودة لـ "+n+" حقول — عدّلها واستبدل ما بين [ ]":"كل الحقول معبّأة؛ امسح حقلاً لتوليد مسودته من جديد")}
function pathCheck(){const P_=PD(),o=[],add=(l,t)=>o.push({l:l,t:t}),pr=parseTitle(S.p.title);
 const req=["prob","obj","q","hyp","method","pop","sample","instr","stats"],miss=PF.filter(f=>req.includes(f[0])&&!String(P_[f[0]]||"").trim()).map(f=>f[1]);
 if(miss.length)add("fl","أقسام ناقصة: "+miss.join("، ")+".");else add("ok","كل الأقسام الأساسية مكتوبة.");
 const all=PF.filter(f=>String(P_[f[0]]||"").includes("[")).map(f=>f[1]);
 if(all.length)add("wr","توجد أقواس [ ] لم تُستبدل بعد في: "+all.join("، ")+".");
 const iv=S.p.iv,dv=S.p.dv,med=S.p.med,hyp=String(P_.hyp||""),stats=String(P_.stats||""),met=String(P_.method||"");
 if(hyp.trim()&&iv&&dv&&!(hyp.includes(iv)&&hyp.includes(dv)))add("wr","الفرضيات لا تذكر المتغيرين «"+iv+"» و«"+dv+"» بنفس صياغتهما في العنوان؛ وحّد المصطلحات.");
 const hn=lns(hyp).filter(x=>/^H\d/i.test(x)).length,qn=lns(P_.q).length;
 if(hn&&qn&&hn>qn)add("wr","عدد الفرضيات ("+hn+") أكبر من عدد الأسئلة ("+qn+"): ينبغي أن يقابل كل فرض سؤال.");
 if(med&&(hyp.trim()||stats.trim())&&!/وساط|وسيط|mediat|Bootstrap|معادلات/i.test(hyp+" "+stats))add("fl","تناقض: حدّدتَ متغيراً وسيطاً «"+med+"» لكن الفرضيات وأساليب التحليل لا تتناول الوساطة.");
 if(/نوعي|مقابلات/.test(met)&&!/مختلط|كمي/.test(met)&&/انحدار|ارتباط|ألفا|كرونباخ/.test(stats))add("fl","تناقض: المنهج نوعي بينما التحليل الإحصائي كمي (انحدار/ارتباط/ثبات).");
 if(pr.design==="relation"&&/(^|\n)H[\d.]*:\s*يوجد أثر/.test(hyp))add("wr","عنوانك يصوغ «علاقة» لكن الفرضيات تدّعي «أثراً»؛ وحّد الصياغة بين العنوان والفرضيات.");
 if(pr.design==="effect"&&stats.trim()&&!/انحدار|معادلات|SEM|regression/i.test(stats))add("wr","العنوان يدّعي «أثراً» لكن أساليب التحليل لا تتضمن انحداراً أو نمذجة معادلات بنائية.");
 const N=num(P_.N),sm=String(P_.sample||"").match(/الحد الأدنى\s+(\d{2,5})/)||String(P_.sample||"").match(/(\d{2,5})/);
 if(N>0&&sm&&num(sm[1])<sampleSize(N))add("wr","العينة المذكورة ("+sm[1]+") أقل من الحد الأدنى المحسوب ("+sampleSize(N)+") لمجتمع من "+N+".");
 if(String(P_.instr||"").trim()&&!/ثبات|صدق/.test(P_.instr))add("wr","وصف الأداة لا يذكر الصدق أو الثبات.");
 if(!String(S.p.sector||"").trim())add("wr","لم تُحدّد الجهة/القطاع في بيانات الدراسة.");
 const tg=num(S.p.target)||10;if(S.studies.length<tg)add("wr","الدراسات السابقة المسجلة "+S.studies.length+" من "+tg+" مستهدفة.");
 if(String(P_.res||"").trim()||String(P_.rec||"").trim())add("wr","تأكد أن «النتائج/التوصيات» مبنية على بيانات ميدانية حقيقية جُمعت وحُللت فعلاً، لا على توقعات.");
 return o}
function vPath(){const P_=PD(),N=num(P_.N);
 let h='<div class="card"><h2>🧭 مسار الرسالة</h2><p class="hint">من المشكلة إلى التحليل الإحصائي. زر التوليد ينشئ <b>مسودة قابلة للتعديل</b> من عنوانك ومتغيراتك فقط (دون اختلاق مراجع أو بيانات)، وما بين [ ] يحتاج منك استبداله بمعلومة حقيقية. أقسام النتائج والتوصيات لا تُكتب قبل جمع البيانات.</p>'+
 '<div class="row"><button class="btn" id="pgen">✨ ولّد المسودة (الحقول الفارغة فقط)</button><button class="btn sec" id="pdocx">📄 تصدير الرسالة (Word .docx)</button></div></div>';
 h+='<div class="card"><h3>حاسبة حجم العينة</h3><div class="grid"><div><label>حجم مجتمع الدراسة (N)</label><input type="number" inputmode="numeric" data-pk="N" value="'+esc(P_.N||"")+'" placeholder="مثال: 1200"></div></div>'+
  '<p class="hint">'+(N>0?'الحد الأدنى بمعادلة كوكران مع التصحيح للمجتمع المحدود (ثقة 95%، هامش خطأ 5%، تباين 0.5): <b>'+sampleSize(N)+'</b> مشاركاً. زِد العدد لتعويض الاستبيانات غير الصالحة.':'أدخل حجم المجتمع لحساب الحد الأدنى. لمجتمع كبير جداً تقترب القيمة من '+sampleSize(0)+'.')+' قواعد إرشادية شائعة (وليست قوانين): لا تقل العينة عن 200 تقريباً في نمذجة المعادلات البنائية، ونحو 10–20 مشاركاً لكل متغير مستقل في الانحدار.</p></div>';
 PF.forEach(f=>{const k=f[0],late=(k==="res"||k==="rec");
  h+='<div class="card"><label for="pk_'+k+'"><b>'+esc(f[1])+'</b></label>'+(late?'<p class="hint">اتركه فارغاً حتى تنتهي من جمع البيانات وتحليلها.</p>':'')+'<textarea id="pk_'+k+'" rows="'+(k==="obj"||k==="q"||k==="hyp"?6:4)+'" data-pk="'+k+'">'+esc(P_[k]||"")+'</textarea></div>'});
 h+='<div class="card"><h3>تنبيهات الاتساق والنواقص</h3>'+pathCheck().map(x=>'<div class="rule" style="border-top:0"><span class="badge '+x.l+'">'+LBL[x.l]+'</span><div>'+esc(x.t)+'</div></div>').join("")+'</div>';
 return h}
/* --- بناء ملف docx حقيقي (بلا مكتبات) --- */
function crc32(u8){let c,crc=-1;if(!crc32.t){crc32.t=[];for(let n=0;n<256;n++){c=n;for(let k=0;k<8;k++)c=c&1?0xEDB88320^(c>>>1):c>>>1;crc32.t[n]=c>>>0}}
 for(let i=0;i<u8.length;i++)crc=crc32.t[(crc^u8[i])&255]^(crc>>>8);return (crc^-1)>>>0}
function zipStore(files){const enc=new TextEncoder(),u16=n=>[n&255,(n>>8)&255],u32=n=>[n&255,(n>>>8)&255,(n>>>16)&255,(n>>>24)&255];
 let off=0;const parts=[],cd=[];
 files.forEach(f=>{const nm=enc.encode(f.name),dt=enc.encode(f.data),crc=crc32(dt),sz=dt.length;
  const lh=new Uint8Array([0x50,0x4b,3,4,...u16(20),...u16(0x0800),...u16(0),...u16(0),...u16(0x21),...u32(crc),...u32(sz),...u32(sz),...u16(nm.length),...u16(0)]);
  parts.push(lh,nm,dt);
  cd.push(new Uint8Array([0x50,0x4b,1,2,...u16(20),...u16(20),...u16(0x0800),...u16(0),...u16(0),...u16(0x21),...u32(crc),...u32(sz),...u32(sz),...u16(nm.length),...u16(0),...u16(0),...u16(0),...u16(0),...u32(0),...u32(off)]),nm);
  off+=lh.length+nm.length+sz});
 const cds=cd.reduce((s,x)=>s+x.length,0);
 const eo=new Uint8Array([0x50,0x4b,5,6,...u16(0),...u16(0),...u16(files.length),...u16(files.length),...u32(cds),...u32(off),...u16(0)]);
 const all=parts.concat(cd,[eo]),tot=all.reduce((s,x)=>s+x.length,0),out=new Uint8Array(tot);let p=0;all.forEach(x=>{out.set(x,p);p+=x.length});return out}
const XM=s=>String(s==null?"":s).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g,"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
function dxR(t,o){o=o||{};const sz=o.sz||24;return '<w:r><w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial" w:cs="Arial"/>'+(o.b?'<w:b/><w:bCs/>':'')+'<w:sz w:val="'+sz+'"/><w:szCs w:val="'+sz+'"/><w:rtl/></w:rPr><w:t xml:space="preserve">'+XM(t)+'</w:t></w:r>'}
function dxP(t,o){o=o||{};return '<w:p><w:pPr>'+(o.style?'<w:pStyle w:val="'+o.style+'"/>':'')+'<w:bidi/><w:spacing w:after="120" w:line="360" w:lineRule="auto"/>'+(o.center?'<w:jc w:val="center"/>':'')+'</w:pPr>'+String(t).split("\n").map((ln,i)=>(i?'<w:r><w:br/></w:r>':'')+dxR(ln,o)).join("")+'</w:p>'}
function dxTbl(rows,w){const n=rows[0].length,cw=Math.floor(9000/n),b='<w:top w:val="single" w:sz="4" w:space="0" w:color="888888"/><w:left w:val="single" w:sz="4" w:space="0" w:color="888888"/><w:bottom w:val="single" w:sz="4" w:space="0" w:color="888888"/><w:right w:val="single" w:sz="4" w:space="0" w:color="888888"/><w:insideH w:val="single" w:sz="4" w:space="0" w:color="888888"/><w:insideV w:val="single" w:sz="4" w:space="0" w:color="888888"/>';
 return '<w:tbl><w:tblPr><w:bidiVisual/><w:tblW w:w="9000" w:type="dxa"/><w:tblBorders>'+b+'</w:tblBorders></w:tblPr><w:tblGrid>'+rows[0].map(()=>'<w:gridCol w:w="'+cw+'"/>').join("")+'</w:tblGrid>'+
  rows.map((r,i)=>'<w:tr>'+r.map(c=>'<w:tc><w:tcPr><w:tcW w:w="'+cw+'" w:type="dxa"/>'+(i===0?'<w:shd w:val="clear" w:color="auto" w:fill="E8EEF9"/>':'')+'</w:tcPr>'+dxP(c,{b:i===0,sz:20})+'</w:tc>').join("")+'</w:tr>').join("")+'</w:tbl>'+dxP("",{sz:12})}
function docxBytes(body){const NS='xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"';
 const hs=(id,n,sz)=>'<w:style w:type="paragraph" w:styleId="'+id+'"><w:name w:val="'+n+'"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/><w:pPr><w:keepNext/><w:spacing w:before="280" w:after="120"/><w:outlineLvl w:val="'+(+id.slice(-1)-1)+'"/></w:pPr><w:rPr><w:b/><w:bCs/><w:color w:val="16307F"/><w:sz w:val="'+sz+'"/><w:szCs w:val="'+sz+'"/></w:rPr></w:style>';
 const styles='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:styles '+NS+'><w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial" w:cs="Arial"/><w:sz w:val="24"/><w:szCs w:val="24"/><w:lang w:val="en-US" w:bidi="ar-SA"/></w:rPr></w:rPrDefault></w:docDefaults><w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:qFormat/></w:style>'+hs("Heading1","heading 1",32)+hs("Heading2","heading 2",28)+hs("Heading3","heading 3",26)+'</w:styles>';
 const doc='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document '+NS+'><w:body>'+body+'<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1440" w:right="1440" w:bottom="1440" w:left="1440" w:header="708" w:footer="708" w:gutter="0"/><w:bidi/></w:sectPr></w:body></w:document>';
 return zipStore([
  {name:"[Content_Types].xml",data:'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/></Types>'},
  {name:"_rels/.rels",data:'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>'},
  {name:"word/_rels/document.xml.rels",data:'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>'},
  {name:"word/styles.xml",data:styles},{name:"word/document.xml",data:doc}])}
function thesisDocxBody(){const P_=PD();let b="";
 b+=dxP(S.p.title||P().name,{b:true,sz:36,center:true})+dxP("مسودة أولية من «مكتب الرسالة» — تتطلب مراجعة الباحث والمشرف، ولا تتضمن بيانات ميدانية. جميع النصوص التي بين [ ] تحتاج استبدالاً بمعلومات حقيقية.",{sz:20,center:true});
 b+=dxP("بيانات الدراسة",{style:"Heading1",b:true,sz:32})+dxTbl([["البند","القيمة"],["العنوان",S.p.title||"—"],["الدرجة",S.p.deg||"DBA"],["القطاع/الجهة",S.p.sector||"—"],["المتغير المستقل",S.p.iv||"—"],["المتغير التابع",S.p.dv||"—"],["المتغير الوسيط",S.p.med||"—"]]);
 b+=dxP("مسار الرسالة",{style:"Heading1",b:true,sz:32});
 PF.forEach(f=>{const v=String(P_[f[0]]||"").trim();b+=dxP(f[1],{style:"Heading2",b:true,sz:28})+dxP(v||"— لم يُكتب بعد —")});
 b+=dxP("ملاحظات الاتساق والنواقص",{style:"Heading1",b:true,sz:32})+dxTbl([["الحالة","الملاحظة"]].concat(pathCheck().map(x=>[LBL[x.l],x.t])));
 if(S.studies.length)b+=dxP("الدراسات السابقة",{style:"Heading1",b:true,sz:32})+dxTbl([["الباحث","السنة","عنوان الدراسة","أهم النتائج"]].concat(S.studies.map(s=>[s.author||"—",String(s.year||"—"),s.title||"—",s.find||"—"])));
 b+=dxP("المراجع (APA 7)",{style:"Heading1",b:true,sz:32});
 const refs=S.refs.map(r=>String(r.cite||"").trim()).filter(Boolean).sort((a,c)=>a.localeCompare(c));
 b+=refs.length?refs.map((c,i)=>dxP((i+1)+". "+c)).join(""):dxP("— لا توجد مراجع مسجلة بعد —");
 return b}
function exportDocx(){dl("thesis-draft.docx",docxBytes(thesisDocxBody()),"application/vnd.openxmlformats-officedocument.wordprocessingml.document");toast("تم تصدير thesis-draft.docx")}
/* --- استيراد الملفات الأكاديمية: BibTeX / RIS / نص / docx --- */
let IMP=null;
function parseBib(t){const res=[];let i=0;
 while((i=t.indexOf("@",i))>=0){const m=/^@(\w+)\s*\{/.exec(t.slice(i,i+40));if(!m){i++;continue}
  let d=1,j=i+m[0].length;while(j<t.length&&d>0){const c=t[j];if(c==="{")d++;else if(c==="}")d--;j++}
  const body=t.slice(i+m[0].length,j-1);i=j;if(/^(comment|string|preamble)$/i.test(m[1]))continue;
  const f={},k=body.indexOf(","),rest=k>=0?body.slice(k+1):"",fre=/(\w+)\s*=\s*/g;let fm;
  while((fm=fre.exec(rest))){const p=fre.lastIndex,c=rest[p];let v="";
   if(c==="{"){let dd=1,q=p+1;while(q<rest.length&&dd>0){if(rest[q]==="{")dd++;else if(rest[q]==="}")dd--;q++}v=rest.slice(p+1,q-1);fre.lastIndex=q}
   else if(c==='"'){const q=rest.indexOf('"',p+1);v=rest.slice(p+1,q<0?rest.length:q);fre.lastIndex=q<0?rest.length:q+1}
   else{const mm=/^[^,\s}]+/.exec(rest.slice(p));v=mm?mm[0]:"";fre.lastIndex=p+v.length}
   f[fm[1].toLowerCase()]=v.replace(/[{}]/g,"").replace(/\s+/g," ").trim()}
  res.push({type:m[1].toLowerCase(),au:(f.author||"").split(/\s+and\s+/i).map(x=>x.trim()).filter(Boolean),year:f.year||"",ttl:f.title||"",jr:f.journal||f.booktitle||"",vol:f.volume||"",iss:f.number||"",pp:(f.pages||"").replace(/--/g,"–"),doi:f.doi||""})}
 return res}
function parseRis(t){const res=[];let c=null;
 t.split(/\r?\n/).forEach(l=>{const m=/^([A-Z][A-Z0-9])\s\s-\s?(.*)$/.exec(l);if(!m)return;const k=m[1],v=m[2].trim();
  if(k==="TY"){c={type:v.toLowerCase(),au:[],year:"",ttl:"",jr:"",vol:"",iss:"",pp:"",doi:"",sp:"",ep:""};return}
  if(!c)return;
  if(k==="ER"){if(c.ttl||c.doi){if(!c.pp&&c.sp)c.pp=c.sp+(c.ep?"–"+c.ep:"");res.push(c)}c=null;return}
  if(k==="AU"||k==="A1")c.au.push(v);else if(k==="TI"||k==="T1")c.ttl=c.ttl||v;else if(k==="PY"||k==="Y1")c.year=c.year||(v.match(/\d{4}/)||[""])[0];
  else if(k==="JO"||k==="JF"||k==="T2")c.jr=c.jr||v;else if(k==="VL")c.vol=v;else if(k==="IS")c.iss=v;else if(k==="SP")c.sp=v;else if(k==="EP")c.ep=v;else if(k==="DO")c.doi=v.replace(/^https?:\/\/(dx\.)?doi\.org\//i,"")});
 return res}
function apaNm(n){n=String(n||"").trim();if(!n)return"";let last,first;if(n.includes(",")){const p=n.split(",");last=p[0].trim();first=p.slice(1).join(" ").trim()}else{const p=n.split(/\s+/);last=p.pop();first=p.join(" ")}
 return last+(first?", "+first.split(/[\s.\-]+/).filter(Boolean).map(w=>w[0].toUpperCase()+".").join(" "):"")}
function refFromEntry(e){const au=e.au.map(apaNm).filter(Boolean),peer=/article|jour|conf|inproceedings|proceedings/i.test(e.type);
 let c=(au.join(", ")||"?")+(e.year?" ("+e.year+"). ":" (بلا تاريخ). ")+String(e.ttl||"بلا عنوان").replace(/\s+/g," ").trim()+". "+(e.jr||"");
 if(e.vol)c+=", "+e.vol;if(e.iss)c+="("+e.iss+")";if(e.pp)c+=", "+e.pp;c=c.replace(/\s+,/g,",").replace(/\.\s*$/,"");c+="."+(e.doi?" https://doi.org/"+e.doi:"");
 return {cat:(num(e.year)>=num(S.p.minY)&&peer)?"A":"B",lang:hasAr(e.ttl)?"ar":"en",cite:c.trim(),ttl:e.ttl,aut:e.au.join("; "),year:e.year,jr:e.jr,doi:e.doi,peer:peer,just:"",v:undefined}}
function refDupe(r){const d=String(r.doi||"").toLowerCase(),nt=normT(r.ttl);return S.refs.some(x=>(d&&String(x.doi||"").toLowerCase()===d)||(nt&&normT(x.ttl)===nt))}
function findDois(t){const s=new Set();(String(t).match(/10\.\d{4,9}\/[^\s"<>\])},;،؛؟]+/g)||[]).forEach(x=>{x=x.replace(/[.,;:)\]،؛؟]+$/,"").toLowerCase();if(x.length>8)s.add(x)});return Array.from(s)}
async function readDocx(buf){const u=new Uint8Array(buf),dv=new DataView(buf);let e=u.length-22;while(e>=0&&dv.getUint32(e,true)!==0x06054b50)e--;
 if(e<0)throw new Error("ملف docx غير صالح");const n=dv.getUint16(e+10,true);let p=dv.getUint32(e+16,true);
 for(let i=0;i<n;i++){if(dv.getUint32(p,true)!==0x02014b50)break;
  const meth=dv.getUint16(p+10,true),csz=dv.getUint32(p+20,true),nl=dv.getUint16(p+28,true),el=dv.getUint16(p+30,true),cl=dv.getUint16(p+32,true),lo=dv.getUint32(p+42,true),
   name=new TextDecoder().decode(u.subarray(p+46,p+46+nl));p+=46+nl+el+cl;
  if(name==="word/document.xml"){const ds=lo+30+dv.getUint16(lo+26,true)+dv.getUint16(lo+28,true),raw=u.subarray(ds,ds+csz);let xml;
   if(meth===0)xml=new TextDecoder().decode(raw);
   else{if(typeof DecompressionStream==="undefined")throw new Error("متصفحك لا يدعم قراءة docx؛ احفظ الملف كنص (.txt) وأعد المحاولة");
    xml=new TextDecoder().decode(await new Response(new Blob([raw]).stream().pipeThrough(new DecompressionStream("deflate-raw"))).arrayBuffer())}
   return xml.replace(/<\/w:p>/g,"\n").replace(/<w:tab\/>/g,"\t").replace(/<w:br\/>/g,"\n").replace(/<[^>]+>/g,"").replace(/&lt;/g,"<").replace(/&gt;/g,">").replace(/&quot;/g,'"').replace(/&apos;/g,"'").replace(/&amp;/g,"&")}}
 throw new Error("لم أجد نص المستند داخل الملف")}
function readFileAs(f,mode){return new Promise((res,rej)=>{const r=new FileReader();r.onload=()=>res(r.result);r.onerror=()=>rej(new Error("تعذّرت قراءة الملف"));mode==="buf"?r.readAsArrayBuffer(f):r.readAsText(f,"utf-8")})}
async function handleImport(f){if(!f)return;const nm=f.name||"ملف",ext=(nm.split(".").pop()||"").toLowerCase();
 try{let txt="",entries=[];
  if(ext==="pdf"){toast("ملفات PDF غير مدعومة هنا. انسخ النص إلى ملف .txt أو احفظ الملف بصيغة .docx ثم أعد الاستيراد",1);return}
  if(ext==="docx")txt=await readDocx(await readFileAs(f,"buf"));
  else if(["bib","ris","txt","md","csv","enw"].includes(ext))txt=await readFileAs(f,"text");
  else{toast("صيغة غير مدعومة. المدعوم: bib وris وtxt وmd وcsv وdocx",1);return}
  if(ext==="bib")entries=parseBib(txt);else if(ext==="ris")entries=parseRis(txt);
  const refs=entries.map(refFromEntry),fresh=refs.filter(r=>!refDupe(r));
  const dois=(ext==="bib"||ext==="ris")?[]:findDois(txt).filter(d=>!refDupe({doi:d}));
  IMP={name:nm,total:refs.length,fresh:fresh,dois:dois,chars:txt.length};
  if(!refs.length&&!dois.length)toast("لم أجد مراجع أو DOI في «"+nm+"»",1);else toast("تم تحليل «"+nm+"» — راجع النتيجة ثم أضفها");
  render()}
 catch(e){toast((e&&e.message)||"تعذّر استيراد الملف",1)}}
async function refFromDoi(doi){const r=await jget("https://api.crossref.org/works/"+segEnc(doi)),m=r.message;if(!m)return null;
 const au=(m.author||[]).map(a=>a.family?(a.family+", "+String(a.given||"").split(/\s+/).map(w=>w?w[0]+".":"").join(" ")):(a.name||"")).filter(Boolean).join(", "),y=crYear(m)||"",tt=(m.title&&m.title[0])||"",jr=(m["container-title"]&&m["container-title"][0])||m.publisher||"";
 let c=(au||"?")+(y?" ("+y+"). ":" (بلا تاريخ). ")+tt+". "+((m["container-title"]&&m["container-title"][0])||"");if(m.volume)c+=", "+m.volume;if(m.issue)c+="("+m.issue+")";if(m.page)c+=", "+m.page;c+=". "+(m.DOI?"https://doi.org/"+m.DOI:"");
 return {cat:(y>=num(S.p.minY))?"A":"B",lang:hasAr(tt)?"ar":"en",cite:c.replace(/\s+/g," ").trim(),ttl:tt,aut:au,year:y,jr:jr,doi:m.DOI||doi,peer:true,just:"",v:{t:Date.now(),ok:"ok",msg:"✔ جُلبت بياناته من Crossref",src:"Crossref",ct:tt,cy:y,j:jr,typ:m.type,doi:m.DOI||doi}}}
async function impAddDois(){if(!IMP||!IMP.dois.length)return;const w=document.getElementById("impst");let ok=0,bad=0;
 for(const d of IMP.dois.slice(0,40)){if(w)w.textContent="⏳ جارٍ جلب "+(ok+bad+1)+" من "+Math.min(40,IMP.dois.length)+"…";
  try{const r=await refFromDoi(d);if(r&&!refDupe(r)){S.refs.unshift(r);ok++}else bad++}catch(e){bad++}await sleep(250)}
 IMP.dois=IMP.dois.slice(40);save();render();toast("أُضيف "+ok+" مرجعاً من Crossref"+(bad?" — تعذّر "+bad+" (DOI غير موجود أو لا اتصال)":""),!ok)}
function importCard(){let h='<div class="card"><h2>📥 استيراد ملفات أكاديمية</h2><p class="hint">المدعوم: <b>BibTeX/RIS</b> (من Zotero أو Mendeley أو Google Scholar) فتُضاف مراجعها مباشرة، وملفات <b>txt/md/docx</b> فيُستخرج منها أي DOI فيها لتُجلب بياناته الحقيقية من Crossref. ملفات PDF غير مدعومة (انسخ النص أو احفظها docx). الملف يُقرأ داخل متصفحك ولا يُرسل لأحد.</p>'+
 '<label class="btn" style="display:inline-block;margin:0">اختر ملفاً<input type="file" id="impa" accept=".bib,.ris,.txt,.md,.csv,.docx,.pdf" hidden></label>';
 if(IMP)h+='<div class="rule" style="border-top:0;margin-top:10px"><span class="badge ok">نتيجة</span><div><b>'+esc(IMP.name)+'</b><small>مراجع منظّمة: '+IMP.total+' (الجديدة: '+IMP.fresh.length+') · DOI مستخرجة جديدة: '+IMP.dois.length+'</small><span class="hint" id="impst"></span></div></div>'+
  '<div class="row">'+(IMP.fresh.length?'<button class="btn" id="impref">➕ أضف '+IMP.fresh.length+' مرجعاً</button>':'')+(IMP.dois.length?'<button class="btn sec" id="impdoi">🌐 اجلب بيانات '+Math.min(40,IMP.dois.length)+' DOI من Crossref (يحتاج إنترنت)</button>':'')+'</div>';
 return h+'</div>'}

document.addEventListener("click",e=>{const t=e.target.closest("button");if(!t)return;
 if(t.id==="pgen")pathFill();else if(t.id==="pdocx")exportDocx();
 else if(t.id==="navmore"){F.more=!F.more;render()}
 else if(t.id==="impref"&&IMP&&IMP.fresh.length){const n=IMP.fresh.length;IMP.fresh.slice().reverse().forEach(r=>S.refs.unshift(r));IMP.fresh=[];save();render();toast("أُضيف "+n+" مرجعاً — افحصها من تبويب «فحص المراجع»")}
 else if(t.id==="impdoi")impAddDois()});
document.addEventListener("change",e=>{const t=e.target;
 if(t.dataset&&t.dataset.pk!==undefined){PD()[t.dataset.pk]=t.value;save();if(t.dataset.pk==="N")render();return}
 if(t.id==="impa"){const f=t.files&&t.files[0];handleImport(f);try{t.value=""}catch(x){}}});
const _vBackup=VIEWS[9];VIEWS[9]=()=>_vBackup()+importCard();
TABS.push("🧭 مسار الرسالة");VIEWS.push(vPath);

/* ===== المرحلة 4: تثبيت كتطبيق + العمل دون إنترنت ===== */
let DEFERRED=null;
window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();DEFERRED=e;const b=document.getElementById("inst");if(b)b.hidden=false});
window.addEventListener("appinstalled",()=>{DEFERRED=null;const b=document.getElementById("inst");if(b)b.hidden=true;toast("تم تثبيت التطبيق على جهازك")});
document.addEventListener("click",async e=>{const t=e.target.closest("button");if(!t||t.id!=="inst"||!DEFERRED)return;
 DEFERRED.prompt();try{await DEFERRED.userChoice}catch(x){}DEFERRED=null;t.hidden=true});
if("serviceWorker" in navigator&&(location.protocol==="https:"||/^(localhost|127\.0\.0\.1)$/.test(location.hostname))){
 window.addEventListener("load",()=>{navigator.serviceWorker.register("sw.js").catch(()=>{})})}
window.addEventListener("offline",()=>toast("أنت دون اتصال: كل وظائف الكتابة والتنظيم تعمل، والبحث والفحص عبر الإنترنت متوقفان"));
window.addEventListener("online",()=>toast("عاد الاتصال بالإنترنت"));

applyTheme();render();
